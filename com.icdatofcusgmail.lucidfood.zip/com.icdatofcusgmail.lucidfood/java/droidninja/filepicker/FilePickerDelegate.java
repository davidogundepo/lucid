package droidninja.filepicker;

import android.app.Application;
import droidninja.filepicker.utils.image.FrescoManager;

public class FilePickerDelegate extends Application {
    public void onCreate() {
        super.onCreate();
        FrescoManager.init(this);
    }
}
