package droidninja.filepicker.utils.image;

import android.net.Uri;
import android.widget.ImageView;
import droidninja.filepicker.utils.image.ImageLoaderWrapper.ImageOption;
import java.io.File;

public abstract class BaseImageLoader<TARGET extends ImageView, OPTION extends ImageOption> implements ImageLoaderWrapper<TARGET, OPTION> {
    public void showImage(TARGET imageView, String str, OPTION option) {
        showImage((Object) imageView, str == null ? Uri.EMPTY : Uri.parse(str), (ImageOption) option);
    }

    public void showImage(TARGET imageView, File file, OPTION option) {
        showImage((Object) imageView, Uri.fromFile(file), (ImageOption) option);
    }
}
