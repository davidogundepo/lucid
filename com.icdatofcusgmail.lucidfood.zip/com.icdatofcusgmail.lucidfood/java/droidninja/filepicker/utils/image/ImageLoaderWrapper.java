package droidninja.filepicker.utils.image;

import android.net.Uri;
import android.support.annotation.DrawableRes;
import java.io.File;

public interface ImageLoaderWrapper<TARGET, OPTION extends ImageOption> {

    public interface ImageOption {
    }

    OPTION newOption(int i, int i2);

    void showImage(TARGET target, @DrawableRes int i, OPTION option);

    void showImage(TARGET target, Uri uri, OPTION option);

    void showImage(TARGET target, File file, OPTION option);

    void showImage(TARGET target, String str, OPTION option);
}
