package droidninja.filepicker.utils.image;

import android.content.Context;
import android.graphics.Bitmap;
import android.net.Uri;
import android.support.annotation.DrawableRes;
import android.support.annotation.Nullable;
import com.facebook.common.executors.CallerThreadExecutor;
import com.facebook.datasource.DataSource;
import com.facebook.drawee.backends.pipeline.Fresco;
import com.facebook.drawee.backends.pipeline.PipelineDraweeControllerBuilder;
import com.facebook.drawee.view.DraweeView;
import com.facebook.imagepipeline.common.ResizeOptions;
import com.facebook.imagepipeline.datasource.BaseBitmapDataSubscriber;
import com.facebook.imagepipeline.request.ImageRequestBuilder;
import droidninja.filepicker.utils.image.ImageLoaderWrapper.ImageOption;

public class FrescoLoader extends BaseImageLoader<DraweeView, FrescoOption> {

    public static class FrescoOption implements ImageOption {
        private ResizeOptions mResizeOptions;

        public ResizeOptions getResizeOptions() {
            return this.mResizeOptions;
        }

        public void setResizeOptions(ResizeOptions resizeOptions) {
            this.mResizeOptions = resizeOptions;
        }
    }

    public interface RequestCallback {
        void onSuccessed(Bitmap bitmap, float f);
    }

    public FrescoOption newOption(int width, int height) {
        FrescoOption option = new FrescoOption();
        option.setResizeOptions(new ResizeOptions(width, height));
        return option;
    }

    private ImageRequestBuilder getBuilder(Uri uri) {
        return ImageRequestBuilder.newBuilderWithSource(uri);
    }

    private ImageRequestBuilder getBuilder(@DrawableRes int id) {
        return ImageRequestBuilder.newBuilderWithResourceId(id);
    }

    public void showImage(DraweeView imageView, ImageRequestBuilder tBuilder, FrescoOption option) {
        ImageRequestBuilder builder = tBuilder;
        if (!(option == null || option.getResizeOptions() == null)) {
            builder.setResizeOptions(option.getResizeOptions());
        }
        imageView.setController(((PipelineDraweeControllerBuilder) ((PipelineDraweeControllerBuilder) ((PipelineDraweeControllerBuilder) Fresco.newDraweeControllerBuilder().setImageRequest(builder.build())).setOldController(imageView.getController())).setAutoPlayAnimations(true)).build());
    }

    public void showImage(DraweeView imageView, Uri uri, @Nullable FrescoOption option) {
        if (uri.equals(Uri.EMPTY)) {
            imageView.setImageURI(null);
        } else {
            showImage(imageView, getBuilder(uri), option);
        }
    }

    public void showImage(DraweeView imageView, @DrawableRes int id, @Nullable FrescoOption option) {
        showImage(imageView, getBuilder(id), option);
    }

    public static void requestImage(Context context, Uri uri, final float currentPos, final RequestCallback callback) {
        Fresco.getImagePipeline().fetchDecodedImage(ImageRequestBuilder.newBuilderWithSource(uri).setProgressiveRenderingEnabled(true).build(), context).subscribe(new BaseBitmapDataSubscriber() {
            public void onNewResultImpl(@Nullable Bitmap bitmap) {
                callback.onSuccessed(bitmap, currentPos);
            }

            public void onFailureImpl(DataSource dataSource) {
            }
        }, CallerThreadExecutor.getInstance());
    }
}
