package droidninja.filepicker;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.ActionBar;
import android.support.v7.app.AppCompatActivity;
import android.view.Menu;
import android.view.MenuItem;
import droidninja.filepicker.fragments.DocFragment.PhotoPickerFragmentListener;
import droidninja.filepicker.fragments.DocPickerFragment;
import droidninja.filepicker.fragments.PhotoPickerFragment;
import droidninja.filepicker.utils.FragmentUtil;
import java.util.ArrayList;

public class FilePickerActivity extends AppCompatActivity implements PickerManagerListener, PhotoPickerFragmentListener, PhotoPickerFragment.PhotoPickerFragmentListener {
    private static final String TAG = FilePickerActivity.class.getSimpleName();
    private int type;

    protected void onCreate(Bundle savedInstanceState) {
        setTheme(PickerManager.getInstance().getTheme());
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_file_picker);
        if (savedInstanceState == null) {
            initView();
        }
    }

    private void initView() {
        Intent intent = getIntent();
        if (intent != null) {
            setUpToolbar();
            ArrayList<String> selectedPaths = intent.getStringArrayListExtra(FilePickerConst.KEY_SELECTED_PHOTOS);
            this.type = intent.getIntExtra(FilePickerConst.EXTRA_PICKER_TYPE, 17);
            setToolbarTitle(0);
            PickerManager.getInstance().setPickerManagerListener(this);
            openSpecificFragment(this.type, selectedPaths);
        }
    }

    private void setUpToolbar() {
        ActionBar actionBar = getSupportActionBar();
        if (actionBar != null) {
            actionBar.setDisplayHomeAsUpEnabled(true);
        }
    }

    private void openSpecificFragment(int type, ArrayList<String> selectedPaths) {
        if (type == 17) {
            FragmentUtil.addFragment(this, R.id.container, PhotoPickerFragment.newInstance(selectedPaths));
            return;
        }
        FragmentUtil.addFragment(this, R.id.container, DocPickerFragment.newInstance(selectedPaths));
    }

    private void setToolbarTitle(int count) {
        ActionBar actionBar = getSupportActionBar();
        if (actionBar == null) {
            return;
        }
        if (count > 0) {
            actionBar.setTitle("Attachments (" + count + "/" + PickerManager.getInstance().getMaxCount() + ")");
        } else if (this.type == 17) {
            actionBar.setTitle("Select a photo");
        } else {
            actionBar.setTitle("Select a document");
        }
    }

    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.picker_menu, menu);
        return super.onCreateOptionsMenu(menu);
    }

    public boolean onOptionsItemSelected(MenuItem item) {
        int i = item.getItemId();
        if (i == R.id.action_done) {
            Intent intent = new Intent();
            intent.putStringArrayListExtra(FilePickerConst.KEY_SELECTED_PHOTOS, PickerManager.getInstance().getSelectedFilePaths());
            setResult(-1, intent);
            finish();
            return true;
        } else if (i != 16908332) {
            return super.onOptionsItemSelected(item);
        } else {
            onBackPressed();
            return true;
        }
    }

    public void onItemSelected(int currentCount) {
        setToolbarTitle(currentCount);
    }

    public void onBackPressed() {
        super.onBackPressed();
        setResult(0);
        finish();
    }
}
