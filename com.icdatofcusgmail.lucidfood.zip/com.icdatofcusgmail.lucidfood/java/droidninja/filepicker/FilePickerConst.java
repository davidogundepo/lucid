package droidninja.filepicker;

public class FilePickerConst {
    public static final int DEFAULT_COLUMN_NUMBER = 3;
    public static final int DEFAULT_MAX_COUNT = 9;
    public static final int DOC_PICKER = 18;
    public static final String EXTRA_PICKER_TYPE = "EXTRA_PICKER_TYPE";
    public static final String EXTRA_SHOW_GIF = "SHOW_GIF";
    public static final String KEY_SELECTED_PHOTOS = "SELECTED_PHOTOS";
    public static final int PHOTO_PICKER = 17;
    public static final String PPT_MIME_TYPE = "application/mspowerpoint";
    public static final int REQUEST_CODE = 233;

    public enum FILE_TYPE {
        PDF,
        WORD,
        EXCEL,
        PPT,
        TXT,
        UNKNOWN
    }
}
