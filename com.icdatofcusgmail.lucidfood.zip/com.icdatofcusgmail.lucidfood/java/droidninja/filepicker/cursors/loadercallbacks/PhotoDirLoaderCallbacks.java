package droidninja.filepicker.cursors.loadercallbacks;

import android.content.Context;
import android.database.Cursor;
import android.os.Bundle;
import android.support.v4.app.LoaderManager.LoaderCallbacks;
import android.support.v4.content.Loader;
import droidninja.filepicker.FilePickerConst;
import droidninja.filepicker.R;
import droidninja.filepicker.cursors.PhotoDirectoryLoader;
import droidninja.filepicker.models.PhotoDirectory;
import java.lang.ref.WeakReference;
import java.util.ArrayList;
import java.util.List;

public class PhotoDirLoaderCallbacks implements LoaderCallbacks<Cursor> {
    public static final int INDEX_ALL_PHOTOS = 0;
    private WeakReference<Context> context;
    private FileResultCallback<PhotoDirectory> resultCallback;

    public PhotoDirLoaderCallbacks(Context context, FileResultCallback<PhotoDirectory> resultCallback) {
        this.context = new WeakReference(context);
        this.resultCallback = resultCallback;
    }

    public Loader<Cursor> onCreateLoader(int id, Bundle args) {
        return new PhotoDirectoryLoader((Context) this.context.get(), args.getBoolean(FilePickerConst.EXTRA_SHOW_GIF, false));
    }

    public void onLoadFinished(Loader<Cursor> loader, Cursor data) {
        if (data != null) {
            List<PhotoDirectory> directories = new ArrayList();
            PhotoDirectory photoDirectoryAll = new PhotoDirectory();
            photoDirectoryAll.setName(((Context) this.context.get()).getString(R.string.all_images));
            photoDirectoryAll.setId("ALL");
            while (data.moveToNext()) {
                int imageId = data.getInt(data.getColumnIndexOrThrow("_id"));
                String bucketId = data.getString(data.getColumnIndexOrThrow("bucket_id"));
                String name = data.getString(data.getColumnIndexOrThrow("bucket_display_name"));
                String path = data.getString(data.getColumnIndexOrThrow("_data"));
                String fileName = data.getString(data.getColumnIndexOrThrow("title"));
                PhotoDirectory photoDirectory = new PhotoDirectory();
                photoDirectory.setId(bucketId);
                photoDirectory.setName(name);
                if (directories.contains(photoDirectory)) {
                    ((PhotoDirectory) directories.get(directories.indexOf(photoDirectory))).addPhoto(imageId, fileName, path);
                } else {
                    photoDirectory.setCoverPath(path);
                    photoDirectory.addPhoto(imageId, fileName, path);
                    photoDirectory.setDateAdded(data.getLong(data.getColumnIndexOrThrow("date_added")));
                    directories.add(photoDirectory);
                }
                photoDirectoryAll.addPhoto(imageId, fileName, path);
            }
            if (photoDirectoryAll.getPhotoPaths().size() > 0) {
                photoDirectoryAll.setCoverPath((String) photoDirectoryAll.getPhotoPaths().get(0));
            }
            directories.add(0, photoDirectoryAll);
            if (this.resultCallback != null) {
                this.resultCallback.onResultCallback(directories);
            }
        }
    }

    public void onLoaderReset(Loader<Cursor> loader) {
    }
}
