package droidninja.filepicker.cursors;

import android.content.Context;
import android.net.Uri;
import android.provider.MediaStore.Images.Media;
import android.support.v4.content.CursorLoader;
import droidninja.filepicker.BuildConfig;

public class PhotoDirectoryLoader extends CursorLoader {
    final String[] IMAGE_PROJECTION;

    public PhotoDirectoryLoader(Context context, boolean showGif) {
        super(context);
        this.IMAGE_PROJECTION = new String[]{"_id", "_data", "bucket_id", "bucket_display_name", "date_added", "title"};
        setProjection(this.IMAGE_PROJECTION);
        setUri(Media.EXTERNAL_CONTENT_URI);
        setSortOrder("date_added DESC");
        setSelection("mime_type=? or mime_type=? or mime_type=? " + (showGif ? "or mime_type=?" : BuildConfig.FLAVOR));
        setSelectionArgs(showGif ? new String[]{"image/jpeg", "image/png", "image/jpg", "image/gif"} : new String[]{"image/jpeg", "image/png", "image/jpg"});
    }

    private PhotoDirectoryLoader(Context context, Uri uri, String[] projection, String selection, String[] selectionArgs, String sortOrder) {
        super(context, uri, projection, selection, selectionArgs, sortOrder);
        this.IMAGE_PROJECTION = new String[]{"_id", "_data", "bucket_id", "bucket_display_name", "date_added", "title"};
    }
}
