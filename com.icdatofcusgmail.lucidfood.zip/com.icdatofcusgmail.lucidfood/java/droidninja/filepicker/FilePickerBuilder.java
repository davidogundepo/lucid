package droidninja.filepicker;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import java.util.ArrayList;

public class FilePickerBuilder {
    private final Bundle mPickerOptionsBundle = new Bundle();

    public static FilePickerBuilder getInstance() {
        return new FilePickerBuilder();
    }

    public FilePickerBuilder setMaxCount(int maxCount) {
        PickerManager.getInstance().setMaxCount(maxCount);
        return this;
    }

    public FilePickerBuilder setActivityTheme(int theme) {
        PickerManager.getInstance().setTheme(theme);
        return this;
    }

    public FilePickerBuilder setSelectedFiles(ArrayList<String> selectedPhotos) {
        this.mPickerOptionsBundle.putStringArrayList(FilePickerConst.KEY_SELECTED_PHOTOS, selectedPhotos);
        return this;
    }

    public void pickPhoto(Activity context) {
        this.mPickerOptionsBundle.putInt(FilePickerConst.EXTRA_PICKER_TYPE, 17);
        start(context);
    }

    public void pickDocument(Activity context) {
        this.mPickerOptionsBundle.putInt(FilePickerConst.EXTRA_PICKER_TYPE, 18);
        start(context);
    }

    private void start(Activity context) {
        Intent intent = new Intent(context, FilePickerActivity.class);
        intent.putExtras(this.mPickerOptionsBundle);
        context.startActivityForResult(intent, FilePickerConst.REQUEST_CODE);
    }
}
