package droidninja.filepicker.models;

import android.webkit.MimeTypeMap;
import droidninja.filepicker.FilePickerConst;
import droidninja.filepicker.FilePickerConst.FILE_TYPE;
import droidninja.filepicker.R;

public class Document extends BaseFile {
    private String mimeType;
    private String size;

    public Document(int id, String title, String path) {
        super(id, title, path);
    }

    public Document() {
        super(0, null, null);
    }

    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (!(o instanceof Document)) {
            return false;
        }
        if (this.id != ((Document) o).id) {
            return false;
        }
        return true;
    }

    public int hashCode() {
        return this.id;
    }

    public String getPath() {
        return this.path;
    }

    public void setPath(String path) {
        this.path = path;
    }

    public int getId() {
        return this.id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getMimeType() {
        return this.mimeType;
    }

    public void setMimeType(String mimeType) {
        this.mimeType = mimeType;
    }

    public String getSize() {
        return this.size;
    }

    public void setSize(String size) {
        this.size = size;
    }

    public String getTitle() {
        return this.name;
    }

    public void setTitle(String title) {
        this.name = title;
    }

    public int getTypeDrawable() {
        if (getFileType() == FILE_TYPE.EXCEL) {
            return R.drawable.ic_xls;
        }
        if (getFileType() == FILE_TYPE.WORD) {
            return R.drawable.ic_doc;
        }
        if (getFileType() == FILE_TYPE.PPT) {
            return R.drawable.icon_ppt;
        }
        if (getFileType() == FILE_TYPE.PDF) {
            return R.drawable.ic_pdf;
        }
        if (getFileType() == FILE_TYPE.TXT) {
            return R.drawable.ic_txt;
        }
        return R.drawable.ic_doc;
    }

    public boolean isThisType(FILE_TYPE type) {
        if (getFileType() == type) {
            return true;
        }
        return false;
    }

    public FILE_TYPE getFileType() {
        if (this.mimeType == null) {
            return FILE_TYPE.UNKNOWN;
        }
        if (this.mimeType.equals(MimeTypeMap.getSingleton().getMimeTypeFromExtension("xls")) || this.mimeType.equals(MimeTypeMap.getSingleton().getMimeTypeFromExtension("xlsx"))) {
            return FILE_TYPE.EXCEL;
        }
        if (this.mimeType.equals(MimeTypeMap.getSingleton().getMimeTypeFromExtension("doc")) || this.mimeType.equals(MimeTypeMap.getSingleton().getMimeTypeFromExtension("docx")) || this.mimeType.equals(MimeTypeMap.getSingleton().getMimeTypeFromExtension("dot")) || this.mimeType.equals(MimeTypeMap.getSingleton().getMimeTypeFromExtension("dotx"))) {
            return FILE_TYPE.WORD;
        }
        if (this.mimeType.equals(MimeTypeMap.getSingleton().getMimeTypeFromExtension("ppt")) || this.mimeType.equals(MimeTypeMap.getSingleton().getMimeTypeFromExtension("pptx")) || this.mimeType.equals(FilePickerConst.PPT_MIME_TYPE)) {
            return FILE_TYPE.PPT;
        }
        if (this.mimeType.equals(MimeTypeMap.getSingleton().getMimeTypeFromExtension("pdf"))) {
            return FILE_TYPE.PDF;
        }
        if (this.mimeType.equals(MimeTypeMap.getSingleton().getMimeTypeFromExtension("txt"))) {
            return FILE_TYPE.TXT;
        }
        return FILE_TYPE.UNKNOWN;
    }
}
