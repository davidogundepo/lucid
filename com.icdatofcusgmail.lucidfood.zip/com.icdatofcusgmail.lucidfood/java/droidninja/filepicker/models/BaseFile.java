package droidninja.filepicker.models;

public class BaseFile {
    protected int id;
    protected String name;
    protected String path;

    public BaseFile(int id, String name, String path) {
        this.id = id;
        this.name = name;
        this.path = path;
    }

    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (!(o instanceof BaseFile)) {
            return false;
        }
        if (this.id != ((BaseFile) o).id) {
            return false;
        }
        return true;
    }

    public String getPath() {
        return this.path;
    }

    public void setPath(String path) {
        this.path = path;
    }

    public int getId() {
        return this.id;
    }

    public void setId(int id) {
        this.id = id;
    }
}
