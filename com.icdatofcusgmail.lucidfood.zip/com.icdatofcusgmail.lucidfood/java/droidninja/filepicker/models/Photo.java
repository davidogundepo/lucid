package droidninja.filepicker.models;

public class Photo extends BaseFile {
    public Photo(int id, String name, String path) {
        super(id, name, path);
    }

    public Photo() {
        super(0, null, null);
    }

    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (!(o instanceof Photo)) {
            return false;
        }
        if (this.id != ((Photo) o).id) {
            return false;
        }
        return true;
    }

    public int hashCode() {
        return this.id;
    }

    public String getPath() {
        return this.path;
    }

    public void setPath(String path) {
        this.path = path;
    }

    public int getId() {
        return this.id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getName() {
        return this.name;
    }

    public void setName(String name) {
        this.name = name;
    }
}
