package droidninja.filepicker.models;

import android.text.TextUtils;
import java.util.ArrayList;
import java.util.List;

public class PhotoDirectory {
    private String coverPath;
    private long dateAdded;
    private String id;
    private String name;
    private List<Photo> photos = new ArrayList();

    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (!(o instanceof PhotoDirectory)) {
            return false;
        }
        boolean hasId;
        PhotoDirectory directory = (PhotoDirectory) o;
        if (TextUtils.isEmpty(this.id)) {
            hasId = false;
        } else {
            hasId = true;
        }
        boolean otherHasId;
        if (TextUtils.isEmpty(directory.id)) {
            otherHasId = false;
        } else {
            otherHasId = true;
        }
        if (hasId && otherHasId && TextUtils.equals(this.id, directory.id)) {
            return TextUtils.equals(this.name, directory.name);
        }
        return false;
    }

    public int hashCode() {
        if (!TextUtils.isEmpty(this.id)) {
            int result = this.id.hashCode();
            if (TextUtils.isEmpty(this.name)) {
                return result;
            }
            return (result * 31) + this.name.hashCode();
        } else if (TextUtils.isEmpty(this.name)) {
            return 0;
        } else {
            return this.name.hashCode();
        }
    }

    public String getId() {
        return this.id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getCoverPath() {
        return this.coverPath;
    }

    public void setCoverPath(String coverPath) {
        this.coverPath = coverPath;
    }

    public String getName() {
        return this.name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public long getDateAdded() {
        return this.dateAdded;
    }

    public void setDateAdded(long dateAdded) {
        this.dateAdded = dateAdded;
    }

    public List<Photo> getPhotos() {
        return this.photos;
    }

    public void setPhotos(List<Photo> photos) {
        this.photos = photos;
    }

    public List<String> getPhotoPaths() {
        List<String> paths = new ArrayList(this.photos.size());
        for (Photo photo : this.photos) {
            paths.add(photo.getPath());
        }
        return paths;
    }

    public void addPhoto(int id, String name, String path) {
        this.photos.add(new Photo(id, name, path));
    }
}
