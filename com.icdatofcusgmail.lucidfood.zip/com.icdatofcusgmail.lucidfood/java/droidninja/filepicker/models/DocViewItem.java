package droidninja.filepicker.models;

public class DocViewItem {
}
