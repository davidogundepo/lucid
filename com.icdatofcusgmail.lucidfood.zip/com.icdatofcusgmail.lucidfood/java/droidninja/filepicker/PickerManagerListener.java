package droidninja.filepicker;

public interface PickerManagerListener {
    void onItemSelected(int i);
}
