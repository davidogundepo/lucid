package droidninja.filepicker.fragments;

import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.AnimationUtils;

public abstract class BaseFragment extends Fragment {
    protected abstract int getFragmentLayout();

    protected void fadeIn(View view) {
        view.startAnimation(AnimationUtils.loadAnimation(getContext(), 17432576));
        view.setVisibility(0);
    }

    protected void fadeOut(View view) {
        view.startAnimation(AnimationUtils.loadAnimation(getContext(), 17432577));
        view.setVisibility(8);
    }

    @Nullable
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        return inflater.inflate(getFragmentLayout(), container, false);
    }
}
