package droidninja.filepicker.fragments;

import android.content.Context;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import droidninja.filepicker.R;
import droidninja.filepicker.adapters.FileListAdapter;
import droidninja.filepicker.models.Document;
import java.util.ArrayList;
import java.util.List;

public class DocFragment extends BaseFragment {
    private static final String TAG = DocFragment.class.getSimpleName();
    TextView emptyView;
    private FileListAdapter fileListAdapter;
    private PhotoPickerFragmentListener mListener;
    RecyclerView recyclerView;
    private ArrayList<String> selectedPaths;

    public interface PhotoPickerFragmentListener {
    }

    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        return super.onCreateView(inflater, container, savedInstanceState);
    }

    protected int getFragmentLayout() {
        return R.layout.fragment_photo_picker;
    }

    public void onAttach(Context context) {
        super.onAttach(context);
        if (context instanceof PhotoPickerFragmentListener) {
            this.mListener = (PhotoPickerFragmentListener) context;
            return;
        }
        throw new RuntimeException(context.toString() + " must implement PhotoPickerFragmentListener");
    }

    public void onDetach() {
        super.onDetach();
        this.mListener = null;
    }

    public static DocFragment newInstance(ArrayList<String> selectedPaths) {
        DocFragment photoPickerFragment = new DocFragment();
        photoPickerFragment.selectedPaths = selectedPaths;
        return photoPickerFragment;
    }

    public void onViewCreated(View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        setView(view);
        initView();
    }

    private void setView(View view) {
        this.recyclerView = (RecyclerView) view.findViewById(R.id.recyclerview);
        this.emptyView = (TextView) view.findViewById(R.id.empty_view);
    }

    private void initView() {
        this.recyclerView.setLayoutManager(new LinearLayoutManager(getActivity()));
        this.recyclerView.setVisibility(8);
    }

    public void updateList(List<Document> dirs) {
        if (getView() != null) {
            if (dirs.size() > 0) {
                this.recyclerView.setVisibility(0);
                this.emptyView.setVisibility(8);
                FileListAdapter fileListAdapter = (FileListAdapter) this.recyclerView.getAdapter();
                if (fileListAdapter == null) {
                    this.recyclerView.setAdapter(new FileListAdapter(getActivity(), dirs, this.selectedPaths));
                    return;
                }
                fileListAdapter.setData(dirs);
                fileListAdapter.notifyDataSetChanged();
                return;
            }
            this.recyclerView.setVisibility(8);
            this.emptyView.setVisibility(0);
        }
    }
}
