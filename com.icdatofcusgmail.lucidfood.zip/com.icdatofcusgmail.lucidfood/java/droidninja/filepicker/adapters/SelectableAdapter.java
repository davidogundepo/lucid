package droidninja.filepicker.adapters;

import android.support.v7.widget.RecyclerView.Adapter;
import android.support.v7.widget.RecyclerView.ViewHolder;
import droidninja.filepicker.PickerManager;
import droidninja.filepicker.models.BaseFile;
import java.util.ArrayList;
import java.util.List;

public abstract class SelectableAdapter<VH extends ViewHolder, T extends BaseFile> extends Adapter<VH> implements Selectable<T> {
    private static final String TAG = SelectableAdapter.class.getSimpleName();
    private List<T> items;
    protected List<T> selectedPhotos = new ArrayList();

    public SelectableAdapter(List<T> items, List<String> selectedPaths) {
        this.items = items;
        addPathsToSelections(selectedPaths);
    }

    private void addPathsToSelections(List<String> selectedPaths) {
        if (selectedPaths != null) {
            for (int index = 0; index < this.items.size(); index++) {
                for (int jindex = 0; jindex < selectedPaths.size(); jindex++) {
                    if (((BaseFile) this.items.get(index)).getPath().equals(selectedPaths.get(jindex))) {
                        this.selectedPhotos.add(this.items.get(index));
                        PickerManager.getInstance().add((BaseFile) this.items.get(index));
                    }
                }
            }
        }
    }

    public boolean isSelected(T photo) {
        return this.selectedPhotos.contains(photo);
    }

    public void toggleSelection(T photo) {
        if (this.selectedPhotos.contains(photo)) {
            this.selectedPhotos.remove(photo);
        } else {
            this.selectedPhotos.add(photo);
        }
    }

    public void clearSelection() {
        this.selectedPhotos.clear();
    }

    public int getSelectedItemCount() {
        return this.selectedPhotos.size();
    }

    public void setData(List<T> items) {
        this.items = items;
    }

    public List<T> getItems() {
        return this.items;
    }
}
