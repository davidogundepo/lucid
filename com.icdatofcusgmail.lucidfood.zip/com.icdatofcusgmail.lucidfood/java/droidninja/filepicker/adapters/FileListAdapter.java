package droidninja.filepicker.adapters;

import android.content.Context;
import android.support.v7.widget.RecyclerView.ViewHolder;
import android.text.format.Formatter;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import droidninja.filepicker.PickerManager;
import droidninja.filepicker.R;
import droidninja.filepicker.models.BaseFile;
import droidninja.filepicker.models.Document;
import droidninja.filepicker.views.SmoothCheckBox;
import droidninja.filepicker.views.SmoothCheckBox.OnCheckedChangeListener;
import java.util.List;

public class FileListAdapter extends SelectableAdapter<FileViewHolder, Document> {
    private final Context context;

    public static class FileViewHolder extends ViewHolder {
        SmoothCheckBox checkBox;
        TextView fileNameTextView;
        TextView fileSizeTextView;
        ImageView imageView;

        public FileViewHolder(View itemView) {
            super(itemView);
            this.checkBox = (SmoothCheckBox) itemView.findViewById(R.id.checkbox);
            this.imageView = (ImageView) itemView.findViewById(R.id.file_iv);
            this.fileNameTextView = (TextView) itemView.findViewById(R.id.file_name_tv);
            this.fileSizeTextView = (TextView) itemView.findViewById(R.id.file_size_tv);
        }
    }

    public FileListAdapter(Context context, List<Document> items, List<String> selectedPaths) {
        super(items, selectedPaths);
        this.context = context;
    }

    public FileViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        return new FileViewHolder(LayoutInflater.from(this.context).inflate(R.layout.item_doc_layout, parent, false));
    }

    public void onBindViewHolder(final FileViewHolder holder, int position) {
        final Document document = (Document) getItems().get(position);
        holder.imageView.setImageResource(document.getTypeDrawable());
        holder.fileNameTextView.setText(document.getTitle());
        holder.fileSizeTextView.setText(Formatter.formatShortFileSize(this.context, Long.parseLong(document.getSize())));
        holder.itemView.setOnClickListener(new OnClickListener() {
            public void onClick(View v) {
                if (holder.checkBox.isChecked() || PickerManager.getInstance().shouldAdd()) {
                    holder.checkBox.setChecked(!holder.checkBox.isChecked(), true);
                }
            }
        });
        holder.checkBox.setOnCheckedChangeListener(null);
        holder.checkBox.setOnClickListener(new OnClickListener() {
            public void onClick(View v) {
                if (!holder.checkBox.isChecked() && PickerManager.getInstance().shouldAdd()) {
                }
            }
        });
        holder.checkBox.setChecked(isSelected((BaseFile) document));
        holder.itemView.setBackgroundResource(isSelected((BaseFile) document) ? R.color.bg_gray : 17170443);
        holder.checkBox.setOnCheckedChangeListener(new OnCheckedChangeListener() {
            public void onCheckedChanged(SmoothCheckBox checkBox, boolean isChecked) {
                FileListAdapter.this.toggleSelection(document);
                holder.itemView.setBackgroundResource(isChecked ? R.color.bg_gray : 17170443);
                if (isChecked) {
                    PickerManager.getInstance().add(document);
                } else {
                    PickerManager.getInstance().remove(document);
                }
            }
        });
    }

    public int getItemCount() {
        return getItems().size();
    }
}
