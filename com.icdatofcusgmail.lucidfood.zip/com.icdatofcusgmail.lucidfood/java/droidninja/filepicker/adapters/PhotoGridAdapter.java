package droidninja.filepicker.adapters;

import android.content.Context;
import android.net.Uri;
import android.support.v7.widget.RecyclerView.ViewHolder;
import android.util.DisplayMetrics;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.view.WindowManager;
import com.facebook.drawee.view.SimpleDraweeView;
import droidninja.filepicker.PickerManager;
import droidninja.filepicker.R;
import droidninja.filepicker.models.BaseFile;
import droidninja.filepicker.models.Photo;
import droidninja.filepicker.utils.image.FrescoFactory;
import droidninja.filepicker.views.SmoothCheckBox;
import droidninja.filepicker.views.SmoothCheckBox.OnCheckedChangeListener;
import java.io.File;
import java.util.ArrayList;

public class PhotoGridAdapter extends SelectableAdapter<PhotoViewHolder, Photo> {
    public static final int ITEM_TYPE_CAMERA = 100;
    public static final int ITEM_TYPE_PHOTO = 101;
    private OnClickListener cameraOnClickListener;
    private final Context context;
    private int imageSize;

    public static class PhotoViewHolder extends ViewHolder {
        SmoothCheckBox checkBox;
        SimpleDraweeView imageView;
        View selectBg;

        public PhotoViewHolder(View itemView) {
            super(itemView);
            this.checkBox = (SmoothCheckBox) itemView.findViewById(R.id.checkbox);
            this.imageView = (SimpleDraweeView) itemView.findViewById(R.id.iv_photo);
            this.selectBg = itemView.findViewById(R.id.transparent_bg);
        }
    }

    public PhotoGridAdapter(Context context, ArrayList<Photo> photos, ArrayList<String> selectedPaths) {
        super(photos, selectedPaths);
        this.context = context;
        setColumnNumber(context, 3);
    }

    public PhotoViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        return new PhotoViewHolder(LayoutInflater.from(this.context).inflate(R.layout.item_photo_layout, parent, false));
    }

    public int getItemViewType(int position) {
        return position == 0 ? ITEM_TYPE_CAMERA : ITEM_TYPE_PHOTO;
    }

    public void onBindViewHolder(final PhotoViewHolder holder, int position) {
        int i = 0;
        if (getItemViewType(position) == ITEM_TYPE_PHOTO) {
            final Photo photo = (Photo) getItems().get(position - 1);
            FrescoFactory.getLoader().showImage(holder.imageView, Uri.fromFile(new File(photo.getPath())), FrescoFactory.newOption(this.imageSize, this.imageSize));
            holder.itemView.setOnClickListener(new OnClickListener() {
                public void onClick(View v) {
                    if (holder.checkBox.isChecked() || PickerManager.getInstance().shouldAdd()) {
                        holder.checkBox.setChecked(!holder.checkBox.isChecked(), true);
                    }
                }
            });
            holder.checkBox.setVisibility(0);
            holder.checkBox.setOnCheckedChangeListener(null);
            holder.checkBox.setOnClickListener(new OnClickListener() {
                public void onClick(View v) {
                    if (!holder.checkBox.isChecked() && PickerManager.getInstance().shouldAdd()) {
                    }
                }
            });
            holder.checkBox.setChecked(isSelected((BaseFile) photo));
            View view = holder.selectBg;
            if (!isSelected((BaseFile) photo)) {
                i = 8;
            }
            view.setVisibility(i);
            holder.checkBox.setOnCheckedChangeListener(new OnCheckedChangeListener() {
                public void onCheckedChanged(SmoothCheckBox checkBox, boolean isChecked) {
                    PhotoGridAdapter.this.toggleSelection(photo);
                    holder.selectBg.setVisibility(isChecked ? 0 : 8);
                    if (isChecked) {
                        PickerManager.getInstance().add(photo);
                    } else {
                        PickerManager.getInstance().remove(photo);
                    }
                }
            });
            return;
        }
        FrescoFactory.getLoader().showImage(holder.imageView, R.drawable.ic_camera, null);
        holder.checkBox.setVisibility(8);
        holder.itemView.setOnClickListener(this.cameraOnClickListener);
    }

    private void setColumnNumber(Context context, int columnNum) {
        WindowManager wm = (WindowManager) context.getSystemService("window");
        DisplayMetrics metrics = new DisplayMetrics();
        wm.getDefaultDisplay().getMetrics(metrics);
        this.imageSize = metrics.widthPixels / columnNum;
    }

    public int getItemCount() {
        return getItems().size() + 1;
    }

    public void setCameraListener(OnClickListener onClickListener) {
        this.cameraOnClickListener = onClickListener;
    }
}
