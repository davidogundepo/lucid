package droidninja.filepicker.adapters;

public interface Selectable<T> {
    void clearSelection();

    int getSelectedItemCount();

    boolean isSelected(T t);

    void toggleSelection(T t);
}
