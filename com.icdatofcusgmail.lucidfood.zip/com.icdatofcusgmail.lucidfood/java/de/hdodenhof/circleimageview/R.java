package de.hdodenhof.circleimageview;

public final class R {

    public static final class attr {
        public static final int civ_border_color = 2130772150;
        public static final int civ_border_overlay = 2130772151;
        public static final int civ_border_width = 2130772149;
        public static final int civ_fill_color = 2130772152;
    }

    public static final class styleable {
        public static final int[] CircleImageView = new int[]{R.attr.civ_border_width, R.attr.civ_border_color, R.attr.civ_border_overlay, R.attr.civ_fill_color};
        public static final int CircleImageView_civ_border_color = 1;
        public static final int CircleImageView_civ_border_overlay = 2;
        public static final int CircleImageView_civ_border_width = 0;
        public static final int CircleImageView_civ_fill_color = 3;
    }
}
