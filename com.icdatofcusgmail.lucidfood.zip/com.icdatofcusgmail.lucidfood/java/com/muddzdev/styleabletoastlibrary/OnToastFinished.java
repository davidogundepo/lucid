package com.muddzdev.styleabletoastlibrary;

public interface OnToastFinished {
    void onToastFinished();
}
