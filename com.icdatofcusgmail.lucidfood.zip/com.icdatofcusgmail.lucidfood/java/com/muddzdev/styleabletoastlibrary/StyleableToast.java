package com.muddzdev.styleabletoastlibrary;

import android.content.Context;
import android.content.res.TypedArray;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Build.VERSION;
import android.support.annotation.ColorInt;
import android.support.annotation.DrawableRes;
import android.support.annotation.StyleRes;
import android.view.View;
import android.view.animation.Animation;
import android.view.animation.LinearInterpolator;
import android.view.animation.RotateAnimation;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.RelativeLayout.LayoutParams;
import android.widget.TextView;
import android.widget.Toast;
import com.facebook.imageutils.JfifUtil;

public class StyleableToast implements OnToastFinished {
    private static final int DEFAULT_ALPHA = 230;
    private static final int DEFAULT_BACKGROUND = Color.parseColor("#555555");
    private static final String DEFAULT_CONDENSED_FONT = "sans-serif-condensed";
    private static final int DEFAULT_CORNER_RADIUS = 25;
    private static final int DEFAULT_HORIZONTAL_PADDING = 25;
    private static final int DEFAULT_TEXT_COLOR = -1;
    private static final int DEFAULT_TEXT_SIZE = 16;
    private static final int DEFAULT_VERTICAL_PADDING = 11;
    private static int MAX_ALPHA = JfifUtil.MARKER_FIRST_BYTE;
    private static final String TAG = "StyleableToast";
    private int alpha;
    private int backgroundColor;
    private final Context context;
    private int cornerRadius = DEFAULT_TEXT_COLOR;
    private int drawable;
    private int duration;
    private Typeface font;
    private boolean isAnimation;
    private boolean isBold;
    private int strokeColor;
    private float strokeWidth;
    private int style;
    private int textColor;
    private TextView textView;
    private String toastMsg;

    public StyleableToast(Context context) {
        this.context = context.getApplicationContext();
    }

    public StyleableToast(Context context, String toastMsg, int duration) {
        this.context = context.getApplicationContext();
        this.toastMsg = toastMsg;
        this.duration = duration;
    }

    public StyleableToast(Context context, String toastMsg, int duration, @StyleRes int styleId) {
        this.context = context.getApplicationContext();
        this.toastMsg = toastMsg;
        this.duration = duration;
        this.style = styleId;
    }

    public void setStyle(@StyleRes int style) {
        this.style = style;
    }

    public void setToastMsg(String toastMsg) {
        this.toastMsg = toastMsg;
    }

    public void setBoldText() {
        this.isBold = true;
    }

    public void setTextFont(Typeface typeface) {
        this.font = typeface;
    }

    public void setTextColor(@ColorInt int textColor) {
        this.textColor = textColor;
    }

    public void setTextStyle(boolean isBold, Typeface font) {
        this.textColor = this.textColor;
        this.font = font;
    }

    public void setTextStyle(@ColorInt int textColor, Typeface font) {
        this.textColor = textColor;
        this.font = font;
    }

    public void setTextStyle(@ColorInt int textColor, boolean isBold) {
        this.textColor = textColor;
        this.isBold = isBold;
    }

    public void setTextStyle(@ColorInt int textColor, boolean isBold, Typeface font) {
        this.textColor = textColor;
        this.isBold = isBold;
        this.font = font;
    }

    public StyleableToast spinIcon() {
        this.isAnimation = true;
        return this;
    }

    public void setBackgroundColor(@ColorInt int backgroundColor) {
        this.backgroundColor = backgroundColor;
    }

    public void setDuration(int duration) {
        this.duration = duration;
    }

    public void setToastStroke(int strokeWidth, @ColorInt int strokeColor) {
        this.strokeWidth = (float) strokeWidth;
        this.strokeColor = strokeColor;
    }

    public void setCornerRadius(int cornerRadius) {
        this.cornerRadius = cornerRadius;
    }

    public void setMaxAlpha() {
        this.alpha = MAX_ALPHA;
    }

    public void setIcon(@DrawableRes int drawable) {
        this.drawable = drawable;
    }

    private Toast buildToast() {
        Toast toast = new Toast(this.context);
        toast.setDuration(this.duration);
        toast.setView(getToastLayout());
        return toast;
    }

    private View getToastLayout() {
        getImageViewStyleAttr();
        int horizontalPadding = (int) Utils.getTypedValueInDP(this.context, 25.0f);
        int verticalPadding = (int) Utils.getTypedValueInDP(this.context, 11.0f);
        RelativeLayout toastLayout = new RelativeLayout(this.context);
        toastLayout.setPadding(horizontalPadding, verticalPadding, horizontalPadding, verticalPadding);
        toastLayout.setBackground(getToastShape());
        toastLayout.addView(getTextView());
        if (this.drawable > 0) {
            toastLayout.addView(getIcon());
            toastLayout.setPadding(DEFAULT_BACKGROUND, verticalPadding, DEFAULT_BACKGROUND, verticalPadding);
        }
        return toastLayout;
    }

    private void getToastShapeAttrs() {
        if (this.style > 0) {
            int[] floatAttrs = new int[]{16843551, 16843783};
            int[] dimenAttrs = new int[]{16843176};
            TypedArray colors = this.context.obtainStyledAttributes(this.style, new int[]{16842801, 16843782});
            TypedArray floats = this.context.obtainStyledAttributes(this.style, floatAttrs);
            TypedArray dimens = this.context.obtainStyledAttributes(this.style, dimenAttrs);
            this.backgroundColor = colors.getColor(DEFAULT_BACKGROUND, DEFAULT_BACKGROUND);
            this.cornerRadius = (int) dimens.getDimension(DEFAULT_BACKGROUND, 25.0f);
            this.alpha = (int) floats.getFloat(DEFAULT_BACKGROUND, 230.0f);
            if (VERSION.SDK_INT >= 21) {
                this.strokeWidth = floats.getFloat(1, 0.0f);
                this.strokeColor = colors.getColor(1, DEFAULT_BACKGROUND);
            }
            colors.recycle();
            floats.recycle();
            dimens.recycle();
        }
    }

    private GradientDrawable getToastShape() {
        getToastShapeAttrs();
        GradientDrawable gradientDrawable = new GradientDrawable();
        gradientDrawable.setCornerRadius(getShapeCornerRadius());
        gradientDrawable.setStroke((int) getStrokeWidth(), getStrokeColor());
        gradientDrawable.setColor(getBackgroundColor());
        gradientDrawable.setAlpha(getShapeAlpha());
        return gradientDrawable;
    }

    private void getTextStylesAttr() {
        if (this.style > 0) {
            int[] stringAttrs = new int[]{16843692};
            int[] intsAttrs = new int[]{16842903};
            TypedArray colors = this.context.obtainStyledAttributes(this.style, new int[]{16842904});
            TypedArray strings = this.context.obtainStyledAttributes(this.style, stringAttrs);
            TypedArray ints = this.context.obtainStyledAttributes(this.style, intsAttrs);
            this.textColor = colors.getColor(DEFAULT_BACKGROUND, DEFAULT_TEXT_COLOR);
            String passedFont = strings.getString(DEFAULT_BACKGROUND);
            if (!(passedFont == null || passedFont.isEmpty())) {
                if (passedFont.contains("fonts")) {
                    this.font = Typeface.createFromAsset(this.context.getAssets(), passedFont);
                } else {
                    this.font = Typeface.create(passedFont, DEFAULT_BACKGROUND);
                }
            }
            if (ints.getInt(DEFAULT_BACKGROUND, DEFAULT_BACKGROUND) == 1) {
                this.isBold = true;
            } else {
                this.isBold = false;
            }
            colors.recycle();
            strings.recycle();
            ints.recycle();
        }
    }

    private TextView getTextView() {
        getTextStylesAttr();
        this.textView = new TextView(this.context);
        this.textView.setText(this.toastMsg);
        this.textView.setTextSize(2, 16.0f);
        this.textView.setTextColor(getTextColor());
        this.textView.setTypeface(getTypeface());
        this.textView.setMaxLines(2);
        if (this.drawable > 0) {
            int leftPadding = (int) Utils.getTypedValueInDP(this.context, 41.0f);
            int rightPadding = (int) Utils.getTypedValueInDP(this.context, 22.0f);
            LayoutParams layoutParams = new LayoutParams(-2, -2);
            layoutParams.addRule(13);
            this.textView.setLayoutParams(layoutParams);
            this.textView.setPadding(leftPadding, DEFAULT_BACKGROUND, rightPadding, DEFAULT_BACKGROUND);
        }
        return this.textView;
    }

    private Animation getAnimation() {
        if (!this.isAnimation) {
            return null;
        }
        RotateAnimation anim = new RotateAnimation(0.0f, 360.0f, 1, 0.5f, 1, 0.5f);
        anim.setInterpolator(new LinearInterpolator());
        anim.setRepeatCount(DEFAULT_TEXT_COLOR);
        anim.setDuration(1000);
        return anim;
    }

    private void getImageViewStyleAttr() {
        if (this.style > 0) {
            TypedArray drawableId = this.context.obtainStyledAttributes(this.style, new int[]{16842754});
            this.drawable = drawableId.getResourceId(DEFAULT_BACKGROUND, DEFAULT_BACKGROUND);
            drawableId.recycle();
        }
    }

    private ImageView getIcon() {
        if (this.drawable <= 0) {
            return null;
        }
        int marginLeft = (int) Utils.getTypedValueInDP(this.context, 15.0f);
        int maxHeightVal = (int) Utils.getTypedValueInDP(this.context, 20.0f);
        int maxWidthVal = (int) Utils.getTypedValueInDP(this.context, 20.0f);
        ImageView imageView = new ImageView(this.context);
        imageView.setImageDrawable(this.context.getResources().getDrawable(this.drawable));
        imageView.setAnimation(getAnimation());
        imageView.setMaxWidth(marginLeft + maxWidthVal);
        imageView.setMaxHeight(maxHeightVal);
        imageView.setAdjustViewBounds(true);
        LayoutParams layoutParams = new LayoutParams(-2, -2);
        layoutParams.setMargins(marginLeft, DEFAULT_BACKGROUND, DEFAULT_BACKGROUND, DEFAULT_BACKGROUND);
        layoutParams.addRule(15);
        imageView.setLayoutParams(layoutParams);
        return imageView;
    }

    private float getStrokeWidth() {
        return Utils.getTypedValueInDP(this.context, this.strokeWidth);
    }

    private int getStrokeColor() {
        return this.strokeColor;
    }

    private float getShapeCornerRadius() {
        if (this.cornerRadius >= 0) {
            return Utils.getTypedValueInDP(this.context, (float) this.cornerRadius);
        }
        return Utils.getTypedValueInDP(this.context, 25.0f);
    }

    private int getBackgroundColor() {
        if (this.backgroundColor == 0) {
            return DEFAULT_BACKGROUND;
        }
        return this.backgroundColor;
    }

    private int getShapeAlpha() {
        if (this.alpha == 0) {
            return DEFAULT_ALPHA;
        }
        return this.alpha;
    }

    private Typeface getTypeface() {
        if (this.isBold && this.font == null) {
            return Typeface.create(DEFAULT_CONDENSED_FONT, 1);
        }
        if (this.isBold && this.font != null) {
            return Typeface.create(this.font, 1);
        }
        if (this.font != null) {
            return Typeface.create(this.font, DEFAULT_BACKGROUND);
        }
        return Typeface.create(DEFAULT_CONDENSED_FONT, DEFAULT_BACKGROUND);
    }

    @ColorInt
    private int getTextColor() {
        if (this.textColor != 0 || this.style > 0) {
            return this.textColor;
        }
        return DEFAULT_TEXT_COLOR;
    }

    public void show() {
        buildToast().show();
        if (this.isAnimation) {
            ToastDurationWatcher toastDurationWatcher = new ToastDurationWatcher(buildToast().getDuration(), this);
        }
    }

    public void onToastFinished() {
        getAnimation().cancel();
        getAnimation().reset();
    }

    public static StyleableToast makeText(Context context, CharSequence text, int duration, int style) {
        return new StyleableToast(context, text.toString(), duration, style);
    }
}
