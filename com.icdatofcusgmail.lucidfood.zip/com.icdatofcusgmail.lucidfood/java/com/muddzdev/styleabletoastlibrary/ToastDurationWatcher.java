package com.muddzdev.styleabletoastlibrary;

import android.os.CountDownTimer;

public class ToastDurationWatcher {
    private static final int LENGTH_LONG = 3500;
    private static final int LENGTH_SHORT = 2000;
    private int duration;
    private OnToastFinished onToastFinished;

    public ToastDurationWatcher(int duration, OnToastFinished onToastFinished) {
        this.duration = duration;
        this.onToastFinished = onToastFinished;
        trackToastDuration();
    }

    private void trackToastDuration() {
        new CountDownTimer(getToastDuration() + 500, 1000) {
            public void onTick(long millisUntilFinished) {
            }

            public void onFinish() {
                if (ToastDurationWatcher.this.onToastFinished != null) {
                    ToastDurationWatcher.this.onToastFinished.onToastFinished();
                }
            }
        }.start();
    }

    private long getToastDuration() {
        if (this.duration == 1) {
            return 3500;
        }
        return 2000;
    }
}
