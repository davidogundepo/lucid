package com.icdatofcusgmail.lucidfood;

import android.app.Dialog;
import android.app.DialogFragment;
import android.content.DialogInterface;
import android.content.DialogInterface.OnClickListener;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.os.Bundle;
import android.support.v7.app.AlertDialog.Builder;
import android.widget.CheckBox;
import com.muddzdev.styleabletoastlibrary.StyleableToast;
import droidninja.filepicker.R;

public class ConfirmPurchase extends DialogFragment {
    CheckBox checkBoxx;

    public Dialog onCreateDialog(Bundle savedInstanceState) {
        Builder builder = new Builder(getActivity());
        builder.setTitle("Confirm Purchase");
        this.checkBoxx = (CheckBox) getActivity().findViewById(R.id.sendpackalso);
        builder.setMessage("The items you selected will be bought by clicking \nDONE");
        builder.setView(getActivity().getLayoutInflater().inflate(R.layout.fa_confirmpurchase_dialogue, null));
        setCancelable(false);
        builder.setNegativeButton(R.string.cancel, new OnClickListener() {
            public void onClick(DialogInterface dialog, int which) {
                StyleableToast NotConfirmed = new StyleableToast(ConfirmPurchase.this.getActivity(), "Transaction not Confirmed", 0).spinIcon();
                NotConfirmed.setBackgroundColor(Color.parseColor("#FF5A5F"));
                NotConfirmed.setTextColor(-1);
                NotConfirmed.show();
            }
        });
        builder.setPositiveButton(R.string.done, new OnClickListener() {
            public void onClick(DialogInterface dialog, int which) {
                ConfirmPurchase.this.sendData();
            }
        }).setIcon(R.drawable.a_announcement);
        Dialog dialog = builder.create();
        dialog.getWindow().setBackgroundDrawable(new ColorDrawable(-3355444));
        dialog.show();
        return dialog;
    }

    private void sendData() {
        StyleableToast TranCompleted = new StyleableToast(getActivity(), "Transaction Verified", 0).spinIcon();
        TranCompleted.setBackgroundColor(Color.parseColor("#FF5A5F"));
        TranCompleted.setTextColor(-1);
        TranCompleted.setIcon(R.drawable.fa_confirmpurchasetoasticon);
        TranCompleted.show();
        Intent intent = new Intent(getActivity(), ServingActivity.class);
        intent.putExtras(new Bundle());
        startActivity(intent);
    }
}
