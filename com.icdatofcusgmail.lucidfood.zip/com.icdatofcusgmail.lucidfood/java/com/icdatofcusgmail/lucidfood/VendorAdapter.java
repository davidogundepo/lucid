package com.icdatofcusgmail.lucidfood;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.CheckBox;
import android.widget.ImageView;
import android.widget.TextView;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

public class VendorAdapter extends BaseAdapter {
    private Context c;
    private ArrayList<Icdat> icdats;
    private Map<Integer, Boolean> isCheckMap = new HashMap();

    public static class ViewHolder {
        public CheckBox checkBox = null;
        public Object object = null;
    }

    VendorAdapter(Context c, ArrayList<Icdat> icdats) {
        this.c = c;
        this.icdats = icdats;
    }

    public int getCount() {
        return this.icdats == null ? 0 : this.icdats.size();
    }

    public Object getItem(int position) {
        return this.icdats.get(position);
    }

    public long getItemId(int position) {
        return 0;
    }

    public View getView(int position, View convertView, ViewGroup parent) {
        LayoutInflater inflater = (LayoutInflater) this.c.getSystemService("layout_inflater");
        if (convertView == null) {
            convertView = inflater.inflate(R.layout.va_imagemodel, parent, false);
        }
        Icdat icdat = (Icdat) this.icdats.get(position);
        TextView textView = (TextView) convertView.findViewById(R.id.textmodel);
        CheckBox checkBox = (CheckBox) convertView.findViewById(R.id.checkboxmodel);
        ((ImageView) convertView.findViewById(R.id.imagemodel)).setImageResource(((Icdat) this.icdats.get(position)).getFoodimage());
        textView.setText(((Icdat) this.icdats.get(position)).getFoodname());
        return convertView;
    }

    public ArrayList<Icdat> getIcdats() {
        return this.icdats;
    }
}
