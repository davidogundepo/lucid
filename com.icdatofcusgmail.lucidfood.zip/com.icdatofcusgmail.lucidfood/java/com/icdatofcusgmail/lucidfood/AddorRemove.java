package com.icdatofcusgmail.lucidfood;

import android.app.Dialog;
import android.app.DialogFragment;
import android.content.DialogInterface;
import android.content.DialogInterface.OnClickListener;
import android.graphics.Color;
import android.os.Bundle;
import android.support.v7.app.AlertDialog.Builder;
import com.muddzdev.styleabletoastlibrary.StyleableToast;

public class AddorRemove extends DialogFragment {
    public Dialog onCreateDialog(Bundle savedInstanceState) {
        Builder builder = new Builder(getActivity());
        builder.setItems(R.array.AorR, new OnClickListener() {
            public void onClick(DialogInterface dialog, int which) {
                if (which == 0) {
                    StyleableToast AddItems = new StyleableToast(AddorRemove.this.getActivity(), "Adding Items", 0).spinIcon();
                    AddItems.setBackgroundColor(Color.parseColor("#FF5A5F"));
                    AddItems.setTextColor(-1);
                    AddItems.show();
                }
                if (which == 1) {
                    StyleableToast RemoveItems = new StyleableToast(AddorRemove.this.getActivity(), "Removing Items", 0).spinIcon();
                    RemoveItems.setBackgroundColor(Color.parseColor("#FF5A5F"));
                    RemoveItems.setTextColor(-1);
                    RemoveItems.show();
                }
                VendorFragment.ShowInThis.setVisibility(0);
            }
        });
        setCancelable(true);
        return builder.create();
    }
}
