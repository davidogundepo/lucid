package com.icdatofcusgmail.lucidfood;

public class Icdat {
    private int foodimage;
    private String foodname;

    Icdat(String foodname, int foodimage) {
        this.foodimage = foodimage;
        this.foodname = foodname;
    }

    public String getFoodname() {
        return this.foodname;
    }

    public void setFoodname(String foodname) {
        this.foodname = foodname;
    }

    int getFoodimage() {
        return this.foodimage;
    }

    public void setFoodimage(int foodimage) {
        this.foodimage = foodimage;
    }
}
