package com.icdatofcusgmail.lucidfood;

import android.app.Fragment;
import android.content.res.Resources;
import android.graphics.Color;
import android.os.Build.VERSION;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.Adapter;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.GridView;
import android.widget.Toast;
import com.icdatofcusgmail.lucidfood.VendorAdapter.ViewHolder;
import com.muddzdev.styleabletoastlibrary.StyleableToast;
import java.util.ArrayList;

public class VendorFragment extends Fragment implements OnClickListener, OnItemClickListener {
    static GridView ShowInThis;
    private static int visibility;
    Communicator VendorCommunicate;
    private Adapter dweezy = null;
    int[] foodimages = new int[]{R.drawable.c_whiterice, R.drawable.c_jollof, R.drawable.c_friedrice, R.drawable.c_beef, R.drawable.c_chicken, R.drawable.c_moimoi, R.drawable.c_beans, R.drawable.c_egg, R.drawable.c_coleslaw, R.drawable.c_plantain};
    final String[] foodnames = new String[]{"White Rice", "Jollof Rice", "Fried Rice", "Beef", "Chicken", "Moi Moi", "Beans", "Egg", "Coleslaw", "Plantain"};

    public static void setVisibility(int visibility) {
        visibility = visibility;
        ShowInThis.setVisibility(0);
    }

    @Nullable
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_vendor, container, false);
        ShowInThis = (GridView) view.findViewById(R.id.showInThis);
        ShowInThis.setOnItemClickListener(this);
        ShowInThis.setVisibility(8);
        ShowInThis.setAdapter(new VendorAdapter(getActivity(), getIcdats()));
        ShowInThis.setChoiceMode(2);
        ShowInThis.setOnItemClickListener(new OnItemClickListener() {
            public void onItemClick(AdapterView<?> adapterView, View view, int position, long id) {
                if (VERSION.SDK_INT >= 23) {
                    Toast.makeText(VendorFragment.this.getContext(), VendorFragment.this.foodnames[position], 0).show();
                }
            }
        });
        return view;
    }

    private ArrayList<Icdat> getIcdats() {
        ArrayList<Icdat> icdats = new ArrayList();
        icdats.add(new Icdat(this.foodnames[0], this.foodimages[0]));
        icdats.add(new Icdat(this.foodnames[1], this.foodimages[1]));
        icdats.add(new Icdat(this.foodnames[2], this.foodimages[2]));
        icdats.add(new Icdat(this.foodnames[3], this.foodimages[3]));
        icdats.add(new Icdat(this.foodnames[4], this.foodimages[4]));
        icdats.add(new Icdat(this.foodnames[5], this.foodimages[5]));
        icdats.add(new Icdat(this.foodnames[6], this.foodimages[6]));
        icdats.add(new Icdat(this.foodnames[7], this.foodimages[7]));
        icdats.add(new Icdat(this.foodnames[8], this.foodimages[8]));
        icdats.add(new Icdat(this.foodnames[9], this.foodimages[9]));
        return icdats;
    }

    public void onActivityCreated(Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);
        this.VendorCommunicate = (Communicator) getActivity();
        ShowInThis = (GridView) getActivity().findViewById(R.id.showInThis);
        ShowInThis.setAdapter(new VendorAdapter(getActivity(), getIcdats()));
        ShowInThis.setOnItemClickListener(this);
    }

    public void displayGridView(int joseph) {
        Resources ideas = getResources();
        GridView griddisplay = (GridView) getView().findViewById(R.id.showInThis);
    }

    public void onClick(View v) {
    }

    public void onItemClick(AdapterView<?> adapterView, View view, int position, long id) {
        if (view.getTag() instanceof ViewHolder) {
            ((ViewHolder) view.getTag()).checkBox.toggle();
        }
        StyleableToast JustFoodNames = new StyleableToast(getActivity(), this.foodnames[position], 0).spinIcon();
        JustFoodNames.setBackgroundColor(Color.parseColor("#FF5A5F"));
        JustFoodNames.setTextColor(-1);
        JustFoodNames.show();
    }
}
