package com.icdatofcusgmail.lucidfood;

import android.content.DialogInterface;
import android.content.DialogInterface.OnClickListener;
import android.content.Intent;
import android.os.Build.VERSION;
import android.os.Bundle;
import android.support.v7.app.AlertDialog.Builder;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.View;
import android.widget.TextView;
import com.facebook.common.util.ByteConstants;

public class ServingActivity extends AppCompatActivity {
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_serving);
        Log.d("ServingActivity", "onCreate invoked");
        getWindow().addFlags(128);
        getWindow().setFlags(ByteConstants.KB, ByteConstants.KB);
        if (VERSION.SDK_INT >= 21) {
            getWindow().setStatusBarColor(getResources().getColor(17170445));
        }
        ((TextView) findViewById(R.id.textView_result)).setText(getIntent().getExtras().getString("name"));
        ((TextView) findViewById(R.id.textView_result2)).setText(getIntent().getExtras().getString("name2"));
    }

    public void NextTransactionPlease(View view) {
        stopService(new Intent(this, FoodServicing.class));
        startActivity(new Intent(this, VendorActivity.class));
    }

    public void onBackPressed() {
        Builder alertDialog = new Builder(this);
        alertDialog.setTitle("Unnecessary Move");
        alertDialog.setMessage("This action is prevented and unnecessary");
        alertDialog.setIcon(R.drawable.a_alert);
        alertDialog.setNegativeButton("Ok", new OnClickListener() {
            public void onClick(DialogInterface dialog, int which) {
                dialog.dismiss();
            }
        });
        alertDialog.create().show();
    }

    protected void onStart() {
        super.onStart();
        Log.d("ServingActivity", "onStart invoked");
    }

    protected void onResume() {
        super.onResume();
        Log.d("ServingActivity", "onResume invoked");
    }

    protected void onPause() {
        super.onPause();
        Log.d("ServingActivity", "onPause invoked");
    }

    protected void onRestart() {
        super.onRestart();
        Log.d("ServingActivity", "onRestart invoked");
    }

    protected void onDestroy() {
        super.onDestroy();
        Log.d("ServingActivity", "onDestroy invoked");
    }
}
