package com.icdatofcusgmail.lucidfood;

import android.app.Fragment;
import android.content.res.Resources;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.ListView;
import android.widget.SearchView;
import java.util.ArrayList;

public class FoodavailableFragment extends Fragment implements OnItemClickListener {
    Communicator communicator;
    int[] images = new int[]{R.drawable.c_whiterice, R.drawable.c_jollof, R.drawable.c_friedrice, R.drawable.c_beef, R.drawable.c_chicken, R.drawable.c_moimoi, R.drawable.c_plantain, R.drawable.c_egg, R.drawable.c_coleslaw, R.drawable.c_beans};
    ListView listView;
    String[] names = new String[]{"White Rice", "Jollof Rice", "Fried Rice", "Beef", "Chicken", "Moi Moi", "Plantain", "Egg", "Coleslaw", "Beans"};

    @Nullable
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        return inflater.inflate(R.layout.foodmenufragment_foodavailable, container, false);
    }

    public void onActivityCreated(Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);
        this.communicator = (Communicator) getActivity();
        this.listView = (ListView) getActivity().findViewById(R.id.listView);
        this.listView.setAdapter(new FoodmenuAdapter(getActivity(), getTeams()));
        this.listView.setOnItemClickListener(this);
    }

    private ArrayList<Team> getTeams() {
        ArrayList<Team> teams = new ArrayList();
        teams.add(new Team(this.names[0], this.images[0]));
        teams.add(new Team(this.names[1], this.images[1]));
        teams.add(new Team(this.names[2], this.images[2]));
        teams.add(new Team(this.names[3], this.images[3]));
        teams.add(new Team(this.names[4], this.images[4]));
        teams.add(new Team(this.names[5], this.images[5]));
        teams.add(new Team(this.names[6], this.images[6]));
        teams.add(new Team(this.names[7], this.images[7]));
        teams.add(new Team(this.names[8], this.images[8]));
        teams.add(new Team(this.names[9], this.images[9]));
        SearchView searchView = (SearchView) getActivity().findViewById(R.id.searchView);
        return teams;
    }

    public void onItemClick(AdapterView<?> adapterView, View view, int position, long id) {
        this.communicator.respond(position);
    }

    public void changeData(int f) {
        Resources resources = getResources();
        ListView listView = (ListView) getView().findViewById(R.id.listView);
    }
}
