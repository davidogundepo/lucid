package com.icdatofcusgmail.lucidfood;

import android.app.IntentService;
import android.content.Intent;
import android.os.IBinder;
import android.support.annotation.Nullable;
import android.util.Log;

public class FoodServicing extends IntentService {
    public FoodServicing() {
        super("FoodServicing");
    }

    public int onStartCommand(Intent intent, int flags, int startId) {
        Log.d("FoodServicing", "onStartCommand invoked");
        return 1;
    }

    public void onDestroy() {
        Log.d("FoodServicing", "onDestroy invoked");
        super.onDestroy();
    }

    @Nullable
    public IBinder onBind(Intent intent) {
        Log.d("FoodServicing", "onBind invoked");
        return null;
    }

    protected void onHandleIntent(Intent intent) {
        Log.d("FoodServicing", "The Service has started ");
    }
}
