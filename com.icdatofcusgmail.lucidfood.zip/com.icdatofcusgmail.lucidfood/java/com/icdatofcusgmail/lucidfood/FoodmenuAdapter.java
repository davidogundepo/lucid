package com.icdatofcusgmail.lucidfood;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;
import java.util.ArrayList;

public class FoodmenuAdapter extends BaseAdapter {
    private Context d;
    private ArrayList<Team> teams;

    FoodmenuAdapter(Context d, ArrayList<Team> teams) {
        this.d = d;
        this.teams = teams;
    }

    public int getCount() {
        return this.teams.size();
    }

    public Object getItem(int position) {
        return this.teams.get(position);
    }

    public long getItemId(int position) {
        return 0;
    }

    public View getView(int position, View convertView, ViewGroup parent) {
        LayoutInflater inflater = (LayoutInflater) this.d.getSystemService("layout_inflater");
        if (convertView == null) {
            convertView = inflater.inflate(R.layout.fa_imagemodel, parent, false);
        }
        TextView textView2 = (TextView) convertView.findViewById(R.id.textmodel2);
        ((ImageView) convertView.findViewById(R.id.imagemodel2)).setImageResource(((Team) this.teams.get(position)).getFoodimagez());
        textView2.setText(((Team) this.teams.get(position)).getFoodnamez());
        return convertView;
    }
}
