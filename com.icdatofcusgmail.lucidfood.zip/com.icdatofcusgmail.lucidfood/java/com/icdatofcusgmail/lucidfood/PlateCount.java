package com.icdatofcusgmail.lucidfood;

import android.app.Dialog;
import android.app.DialogFragment;
import android.content.DialogInterface;
import android.content.DialogInterface.OnClickListener;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.os.Bundle;
import android.support.v7.app.AlertDialog.Builder;
import android.view.LayoutInflater;
import com.muddzdev.styleabletoastlibrary.StyleableToast;

public class PlateCount extends DialogFragment {
    public Dialog onCreateDialog(Bundle savedInstanceState) {
        Builder builder = new Builder(getActivity());
        LayoutInflater inflater = getActivity().getLayoutInflater();
        builder.setItems(R.array.platenumbers, new OnClickListener() {
            public void onClick(DialogInterface dialog, int which) {
                if (which == 0) {
                    StyleableToast CheckMyMoney = new StyleableToast(PlateCount.this.getActivity(), "You are buying all in a plate", 0).spinIcon();
                    CheckMyMoney.setBackgroundColor(Color.parseColor("#FF5A5F"));
                    CheckMyMoney.setTextColor(-1);
                    CheckMyMoney.show();
                }
                if (which == 1) {
                    CheckMyMoney = new StyleableToast(PlateCount.this.getActivity(), "You are buying all in two diff plates", 0).spinIcon();
                    CheckMyMoney.setBackgroundColor(Color.parseColor("#FF5A5F"));
                    CheckMyMoney.setTextColor(-1);
                    CheckMyMoney.show();
                }
                if (which == 2) {
                    CheckMyMoney = new StyleableToast(PlateCount.this.getActivity(), "You are buying all in three diff plates", 0).spinIcon();
                    CheckMyMoney.setBackgroundColor(Color.parseColor("#FF5A5F"));
                    CheckMyMoney.setTextColor(-1);
                    CheckMyMoney.show();
                }
                if (which == 3) {
                    CheckMyMoney = new StyleableToast(PlateCount.this.getActivity(), "You are buying all in four diff plates", 0).spinIcon();
                    CheckMyMoney.setBackgroundColor(Color.parseColor("#FF5A5F"));
                    CheckMyMoney.setTextColor(-1);
                    CheckMyMoney.show();
                }
                if (which == 4) {
                    CheckMyMoney = new StyleableToast(PlateCount.this.getActivity(), "You are buying all in five diff plates", 0).spinIcon();
                    CheckMyMoney.setBackgroundColor(Color.parseColor("#FF5A5F"));
                    CheckMyMoney.setTextColor(-1);
                    CheckMyMoney.show();
                }
            }
        });
        setCancelable(true);
        Dialog dialog = builder.create();
        dialog.getWindow().setBackgroundDrawable(new ColorDrawable(-3355444));
        dialog.show();
        return dialog;
    }
}
