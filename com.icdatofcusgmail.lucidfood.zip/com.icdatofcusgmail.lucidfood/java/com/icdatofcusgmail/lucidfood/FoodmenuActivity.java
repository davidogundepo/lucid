package com.icdatofcusgmail.lucidfood;

import android.app.FragmentManager;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Color;
import android.os.Build.VERSION;
import android.os.Bundle;
import android.support.design.widget.Snackbar;
import android.support.v7.app.AlertDialog.Builder;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.RelativeLayout;
import com.facebook.common.util.ByteConstants;
import com.icdatofcusgmail.lucidfood.FoodpriceFragment.OnNameSetListener;
import com.muddzdev.styleabletoastlibrary.StyleableToast;
import droidninja.filepicker.BuildConfig;

public class FoodmenuActivity extends AppCompatActivity implements Communicator, OnNameSetListener {
    private RelativeLayout relative;
    private Toolbar toolbar_foodmenu;

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_foodmenu);
        Log.d("FoodmenuActivity", "onCreate invoked");
        getWindow().setFlags(ByteConstants.KB, ByteConstants.KB);
        getWindow().addFlags(128);
        this.relative = (RelativeLayout) findViewById(R.id.activity_foodstuffmenu);
        if (VERSION.SDK_INT >= 21) {
            getWindow().setStatusBarColor(getResources().getColor(17170445));
        }
        this.toolbar_foodmenu = (Toolbar) findViewById(R.id.toolbarfoodmenuactivity);
        setSupportActionBar(this.toolbar_foodmenu);
        getSupportActionBar().setTitle(" FoodMenu");
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        getSupportActionBar().setIcon(R.drawable.c_davooo);
    }

    public void respond(int i) {
        FragmentManager manager = getFragmentManager();
        ((FoodavailableFragment) manager.findFragmentById(R.id.fragmentfoodavailable)).changeData(i);
        ((FoodpriceFragment) manager.findFragmentById(R.id.fragmentfoodprice)).Datachange(i);
    }

    public void FoodMenuFragmentsRespond(int joseph) {
        ((VendorFragment) getFragmentManager().findFragmentById(R.id.displayAddorRemoveDialogue)).displayGridView(joseph);
    }

    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.foodactivityappbarmain, menu);
        return true;
    }

    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case R.id.like_plate /*2131689734*/:
                iLikeThisPlate();
                break;
            case R.id.saved_plate /*2131689735*/:
                showRecentlyBoughtPlates();
                break;
            case R.id.check_balance /*2131689736*/:
                checkMyBalance();
                break;
        }
        return false;
    }

    public void checkMyBalance() {
        Snackbar CheckMyMoney = Snackbar.make(this.relative, "Balance will be Displayed Here", 0);
        CheckMyMoney.setActionTextColor(-16711936);
        CheckMyMoney.show();
    }

    public void iLikeThisPlate() {
        StyleableToast LikePlate = new StyleableToast(this, "I Like You Too", 0).spinIcon();
        LikePlate.setBackgroundColor(Color.parseColor("#FF5A5F"));
        LikePlate.setTextColor(-1);
        LikePlate.setIcon(R.drawable.fa_lovethisplaterotatingtoasticon);
        LikePlate.show();
        Snackbar meetpie = Snackbar.make(this.relative, "Plate Liked and Added to History", 0);
        meetpie.setAction("UNDO", new OnClickListener() {
            public void onClick(View v) {
                Snackbar.make(FoodmenuActivity.this.relative, "Plate Removed Successfully", -1).show();
            }
        });
        meetpie.setActionTextColor(-16711936);
        meetpie.show();
    }

    public void showRecentlyBoughtPlates() {
        StyleableToast RecentlyPurchased = new StyleableToast(this, "Please select from recently bought plates", 1).spinIcon();
        RecentlyPurchased.setBackgroundColor(Color.parseColor("#FF5A5F"));
        RecentlyPurchased.setTextColor(-1);
        RecentlyPurchased.show();
        startActivity(new Intent(this, FoodhistoryActivity.class));
    }

    public void maxPlateCount(View view) {
        new PlateCount().show(getFragmentManager(), "PlateCount");
    }

    public void ConfirmMyPurchase(View view) {
        new ConfirmPurchase().show(getFragmentManager(), "ConfirmPurchase");
    }

    public void setName(String name) {
        ((ChosenfoodFragment) getFragmentManager().findFragmentById(R.id.fragmentchosenfood)).updateInfo(name);
    }

    public void onnItemClick(int i) {
        ((FoodavailableFragment) getFragmentManager().findFragmentById(R.id.fragmentfoodavailable)).changeData(i);
    }

    public void onBackPressed() {
        Builder alertDialog = new Builder(this);
        setTitle(BuildConfig.FLAVOR);
        alertDialog.setTitle("End Transaction");
        alertDialog.setMessage("This action will cancel this current operation. Do you want to cancel your transaction? ");
        alertDialog.setPositiveButton("Yes", new DialogInterface.OnClickListener() {
            public void onClick(DialogInterface dialog, int which) {
                FoodmenuActivity.this.startActivity(new Intent(FoodmenuActivity.this.getApplicationContext(), LoginActivity.class));
            }
        });
        alertDialog.setNegativeButton("No", new DialogInterface.OnClickListener() {
            public void onClick(DialogInterface dialog, int which) {
                dialog.dismiss();
            }
        }).setIcon(R.drawable.a_alert);
        alertDialog.create().show();
    }

    public boolean onSupportNavigateUp() {
        Builder alertDialog = new Builder(this);
        alertDialog.setTitle("End Transaction");
        alertDialog.setMessage("This action will cancel this current operation. Do you want to Cancel your transaction? ");
        alertDialog.setIcon(R.drawable.a_alert);
        alertDialog.setPositiveButton("Yes", new DialogInterface.OnClickListener() {
            public void onClick(DialogInterface dialog, int which) {
                FoodmenuActivity.this.startActivity(new Intent(FoodmenuActivity.this.getApplicationContext(), LoginActivity.class));
            }
        });
        alertDialog.setNegativeButton("No", new DialogInterface.OnClickListener() {
            public void onClick(DialogInterface dialog, int which) {
                dialog.dismiss();
            }
        });
        alertDialog.create().show();
        return true;
    }

    protected void onStart() {
        super.onStart();
        Log.d("FoodmenuActivity", "onStart invoked");
    }

    protected void onResume() {
        super.onResume();
        Log.d("FoodmenuActivity", "onResume invoked");
    }

    protected void onPause() {
        super.onPause();
        Log.d("FoodmenuActivity", "onPause invoked");
    }

    protected void onRestart() {
        super.onRestart();
        Log.d("FoodmenuActivity", "onRestart invoked");
    }

    protected void onDestroy() {
        super.onDestroy();
        Log.d("FoodmenuActivity", "onDestroy invoked");
    }
}
