package com.icdatofcusgmail.lucidfood;

import android.app.Dialog;
import android.app.DialogFragment;
import android.content.DialogInterface;
import android.content.DialogInterface.OnClickListener;
import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.support.v7.app.AlertDialog.Builder;
import android.view.View;
import android.widget.RadioGroup;
import android.widget.RadioGroup.OnCheckedChangeListener;
import com.muddzdev.styleabletoastlibrary.StyleableToast;

public class DynamicPlateCount extends DialogFragment implements OnCheckedChangeListener {
    RadioGroup radioGroup;

    public Dialog onCreateDialog(Bundle savedInstanceState) {
        Builder builder = new Builder(getActivity());
        builder.setTitle("Choose the slightest volume of items available");
        View view = getActivity().getLayoutInflater().inflate(R.layout.va_dynamic_platecount, null);
        builder.setView(view);
        builder.setNegativeButton(R.string.cancel, new OnClickListener() {
            public void onClick(DialogInterface dialog, int which) {
                StyleableToast NoPlateSelected = new StyleableToast(DynamicPlateCount.this.getActivity(), "Please Select Default Plate No.", 0).spinIcon();
                NoPlateSelected.setBackgroundColor(Color.parseColor("#FF5A5F"));
                NoPlateSelected.setTextColor(-1);
                NoPlateSelected.show();
            }
        });
        builder.setPositiveButton(R.string.okay, new OnClickListener() {
            public void onClick(DialogInterface dialog, int which) {
                StyleableToast APlateNoSelected = new StyleableToast(DynamicPlateCount.this.getActivity(), "An Item Selected" + which, 0).spinIcon();
                APlateNoSelected.setBackgroundColor(Color.parseColor("#FF5A5F"));
                APlateNoSelected.setTextColor(-1);
                APlateNoSelected.show();
                dialog.dismiss();
            }
        });
        setCancelable(true);
        Dialog dialog = builder.create();
        dialog.show();
        this.radioGroup = (RadioGroup) view.findViewById(R.id.radiohead);
        this.radioGroup.setOnCheckedChangeListener(this);
        return dialog;
    }

    public void onCheckedChanged(RadioGroup group, int checkedId) {
        switch (checkedId) {
            case R.id.one /*2131689699*/:
                startActivityForResult(new Intent(getActivity(), PlateCount.class), 5);
                return;
            default:
                return;
        }
    }
}
