package com.icdatofcusgmail.lucidfood;

public class Team {
    private int foodimagez;
    private String foodnamez;

    Team(String foodnamez, int foodimagez) {
        this.foodimagez = foodimagez;
        this.foodnamez = foodnamez;
    }

    public String getFoodnamez() {
        return this.foodnamez;
    }

    public void setFoodnamez(String foodnamez) {
        this.foodnamez = foodnamez;
    }

    public int getFoodimagez() {
        return this.foodimagez;
    }

    public void setFoodimagez(int foodimagez) {
        this.foodimagez = foodimagez;
    }
}
