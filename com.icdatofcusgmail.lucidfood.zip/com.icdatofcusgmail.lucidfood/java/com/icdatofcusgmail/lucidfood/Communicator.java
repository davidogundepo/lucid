package com.icdatofcusgmail.lucidfood;

public interface Communicator {
    void FoodMenuFragmentsRespond(int i);

    void respond(int i);
}
