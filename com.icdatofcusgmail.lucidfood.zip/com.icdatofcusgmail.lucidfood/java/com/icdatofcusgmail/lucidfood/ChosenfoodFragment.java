package com.icdatofcusgmail.lucidfood;

import android.app.Fragment;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;

public class ChosenfoodFragment extends Fragment {
    TextView textView;
    TextView textView10th;
    TextView textView2nd;
    TextView textView3rd;
    TextView textView4th;
    TextView textView5th;
    TextView textView6th;
    TextView textView7th;
    TextView textView8th;
    TextView textView9th;

    @Nullable
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.foodmenufragment3_chosenfood, container, false);
        this.textView = (Button) view.findViewById(R.id.Istchosenbutton);
        this.textView.setVisibility(8);
        this.textView2nd = (Button) view.findViewById(R.id.Secondchosenbutton);
        this.textView2nd.setVisibility(8);
        this.textView3rd = (Button) view.findViewById(R.id.Thirdchosenbutton);
        this.textView3rd.setVisibility(8);
        this.textView4th = (Button) view.findViewById(R.id.Fourthchosenbutton);
        this.textView4th.setVisibility(8);
        this.textView5th = (Button) view.findViewById(R.id.Fifthchosenbutton);
        this.textView5th.setVisibility(8);
        this.textView6th = (Button) view.findViewById(R.id.Sixthchosenbutton);
        this.textView6th.setVisibility(8);
        this.textView7th = (Button) view.findViewById(R.id.Seventhchosenbutton);
        this.textView7th.setVisibility(8);
        this.textView8th = (Button) view.findViewById(R.id.Eightchosenbutton);
        this.textView8th.setVisibility(8);
        this.textView9th = (Button) view.findViewById(R.id.Ninthchosenbutton);
        this.textView9th.setVisibility(8);
        this.textView10th = (Button) view.findViewById(R.id.Tenthchosenbutton);
        this.textView10th.setVisibility(8);
        return view;
    }

    public void updateInfo(String name) {
        this.textView.setText(name + " +");
        this.textView.setVisibility(0);
    }
}
