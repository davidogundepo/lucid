package com.icdatofcusgmail.lucidfood;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import com.facebook.common.util.ByteConstants;

public class FoodhistoryActivity extends AppCompatActivity {
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_foodhistory);
        Log.d("FoodhistoryActivity", "onCreate invoked");
        getWindow().setFlags(ByteConstants.KB, ByteConstants.KB);
        getWindow().addFlags(128);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
    }

    protected void onStart() {
        super.onStart();
        Log.d("FoodhistoryActivity", "onStart invoked");
    }

    protected void onResume() {
        super.onResume();
        Log.d("FoodhistoryActivity", "onResume invoked");
    }

    protected void onPause() {
        super.onPause();
        Log.d("FoodhistoryActivity", "onPause invoked");
    }

    protected void onRestart() {
        super.onRestart();
        Log.d("FoodhistoryActivity", "onRestart invoked");
    }

    protected void onDestroy() {
        super.onDestroy();
        Log.d("FoodhistoryActivity", "onDestroy invoked");
    }
}
