package com.icdatofcusgmail.lucidfood;

import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Color;
import android.os.Build.VERSION;
import android.os.Bundle;
import android.support.v7.app.AlertDialog.Builder;
import android.support.v7.app.AppCompatActivity;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.Log;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.animation.AlphaAnimation;
import android.view.animation.Animation;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import com.facebook.common.util.ByteConstants;
import com.muddzdev.styleabletoastlibrary.StyleableToast;
import java.util.ArrayList;
import java.util.Random;

public class LoginActivity extends AppCompatActivity {
    public EditText PasswordField;
    public EditText UsernameField;
    ArrayList<String> arrayRandom;
    public ImageView clearAllPin;
    public ImageView clearAllUsername;
    int intRandom;
    TextView reporterPassword;
    TextView reporterUsername;
    TextView textRandom;

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);
        Log.d("LoginActivity", "onCreate invoked");
        getWindow().addFlags(128);
        getWindow().setFlags(ByteConstants.KB, ByteConstants.KB);
        if (VERSION.SDK_INT >= 21) {
            getWindow().setStatusBarColor(getResources().getColor(17170445));
        }
        this.UsernameField = (EditText) findViewById(R.id.Usernamefield);
        this.PasswordField = (EditText) findViewById(R.id.Passwordfield);
        this.clearAllUsername = (ImageView) findViewById(R.id.clearAllUsername);
        this.clearAllPin = (ImageView) findViewById(R.id.clearAllPin);
        this.clearAllUsername.setVisibility(8);
        this.clearAllPin.setVisibility(8);
        this.reporterPassword = (TextView) findViewById(R.id.reportPassWord);
        this.reporterUsername = (TextView) findViewById(R.id.reportUserName);
        this.textRandom = (TextView) findViewById(R.id.RandomMotivation);
        this.arrayRandom = new ArrayList();
        this.arrayRandom.add("In order to succeed, we must first believe that we can.");
        this.arrayRandom.add("You can't cross the sea merely by standing and staring at the water.");
        this.arrayRandom.add("Always do your best. What you plant now, you will harvest later.");
        this.arrayRandom.add("By failing to prepare, you are preparing to fail.");
        this.arrayRandom.add("If you can dream it, you can do it.");
        this.arrayRandom.add("It always seems impossible until it's done.");
        this.arrayRandom.add("Problems are not stop signs, they are guidelines.");
        this.arrayRandom.add("Always Dream big..One Day you'll Do It..");
        this.PasswordField.addTextChangedListener(new TextWatcher() {
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {
            }

            public void onTextChanged(CharSequence s, int start, int before, int count) {
                LoginActivity.this.clearAllPin.setVisibility(0);
            }

            public void afterTextChanged(Editable no) {
                if (no.length() == 0) {
                    LoginActivity.this.reporterPassword.setText("Not Entered");
                    LoginActivity.this.clearAllPin.setVisibility(4);
                } else if (no.length() < 4) {
                    LoginActivity.this.reporterPassword.setText("Short");
                }
                if (no.length() == 4) {
                    LoginActivity.this.reporterPassword.setText("Max Length");
                }
            }
        });
        this.UsernameField.addTextChangedListener(new TextWatcher() {
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {
            }

            public void onTextChanged(CharSequence s, int start, int before, int count) {
                LoginActivity.this.clearAllUsername.setVisibility(0);
            }

            public void afterTextChanged(Editable no) {
                if (no.length() == 0) {
                    LoginActivity.this.reporterUsername.setText("Not Entered");
                    LoginActivity.this.clearAllUsername.setVisibility(4);
                }
                if (no.length() > 0) {
                    LoginActivity.this.reporterUsername.setText(" ");
                }
            }
        });
        this.clearAllUsername.setOnClickListener(new OnClickListener() {
            public void onClick(View v) {
                LoginActivity.this.UsernameField.getText().clear();
            }
        });
        this.clearAllPin.setOnClickListener(new OnClickListener() {
            public void onClick(View v) {
                LoginActivity.this.PasswordField.getText().clear();
            }
        });
    }

    public void AccessifCorrect(View view) {
        Button button = (Button) findViewById(R.id.loginbutton);
        Animation animation = new AlphaAnimation(1.0f, 0.0f);
        animation.setDuration(1000);
        button.startAnimation(animation);
        if (this.UsernameField.getText().toString().equals("admin") && this.PasswordField.getText().toString().equals("1234")) {
            StyleableToast VeriefiedKorQ = new StyleableToast(getApplicationContext(), "Welcome " + this.UsernameField.getText().toString(), 0).spinIcon();
            VeriefiedKorQ.setBackgroundColor(Color.parseColor("#FF5A5F"));
            VeriefiedKorQ.setTextColor(-1);
            VeriefiedKorQ.show();
            Intent intent = new Intent(this, FoodmenuActivity.class);
            intent.putExtras(new Bundle());
            startActivity(intent);
        } else if (this.UsernameField.getText().toString().isEmpty() && this.PasswordField.getText().toString().isEmpty()) {
            EmptyFields = new StyleableToast(getApplicationContext(), "Please enter your Credentials", 0).spinIcon();
            EmptyFields.setBackgroundColor(Color.parseColor("#FF5A5F"));
            EmptyFields.setTextColor(-1);
            EmptyFields.show();
        } else if (this.UsernameField.getText().toString().isEmpty()) {
            EmptyFields = new StyleableToast(getApplicationContext(), "Please enter your Username", 0).spinIcon();
            EmptyFields.setBackgroundColor(Color.parseColor("#FF5A5F"));
            EmptyFields.setTextColor(-1);
            EmptyFields.show();
        } else if (this.PasswordField.getText().toString().isEmpty()) {
            EmptyFields = new StyleableToast(getApplicationContext(), "Please enter your Password", 0).spinIcon();
            EmptyFields.setBackgroundColor(Color.parseColor("#FF5A5F"));
            EmptyFields.setTextColor(-1);
            EmptyFields.show();
        } else {
            StyleableToast NotVeriefiedKorQ = new StyleableToast(getApplicationContext(), "Wrong Credentials", 0).spinIcon();
            NotVeriefiedKorQ.setBackgroundColor(Color.parseColor("#FF5A5F"));
            NotVeriefiedKorQ.setTextColor(-1);
            NotVeriefiedKorQ.show();
        }
    }

    public void onBackPressed() {
        Builder alertDialog = new Builder(this);
        alertDialog.setTitle("Unnecessary Move");
        alertDialog.setMessage("This action is prevented and unnecessary");
        alertDialog.setIcon(R.drawable.a_alert);
        alertDialog.setNeutralButton("   ", new DialogInterface.OnClickListener() {
            public void onClick(DialogInterface dialog, int which) {
                LoginActivity.this.startActivity(new Intent(LoginActivity.this.getApplicationContext(), VendorActivity.class));
            }
        });
        alertDialog.setNegativeButton("Ok", new DialogInterface.OnClickListener() {
            public void onClick(DialogInterface dialog, int which) {
                dialog.dismiss();
            }
        });
        alertDialog.create().show();
    }

    protected void onStart() {
        super.onStart();
        this.intRandom = new Random().nextInt(4);
        this.textRandom.setText((CharSequence) this.arrayRandom.get(this.intRandom));
        Log.d("LoginActivity", "onStart invoked");
    }

    protected void onResume() {
        super.onResume();
        Log.d("LoginActivity", "onResume invoked");
    }

    protected void onPause() {
        super.onPause();
        Log.d("LoginActivity", "onPause invoked");
    }

    protected void onRestart() {
        super.onRestart();
        Log.d("LoginActivity", "onRestart invoked");
    }

    protected void onDestroy() {
        super.onDestroy();
        Log.d("LoginActivity", "onDestroy invoked");
    }
}
