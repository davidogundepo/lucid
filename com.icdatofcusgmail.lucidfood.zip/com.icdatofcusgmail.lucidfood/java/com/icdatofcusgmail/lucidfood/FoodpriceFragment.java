package com.icdatofcusgmail.lucidfood;

import android.app.Activity;
import android.app.Fragment;
import android.content.res.Resources;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.Button;
import android.widget.TextView;

public class FoodpriceFragment extends Fragment {
    Button button;
    Button button2;
    Button button3;
    Button button4;
    Button button5;
    Button button6;
    OnNameSetListener onNameSetListener;
    TextView textView;
    TextView textView2;
    TextView textView3;
    TextView textView4;
    TextView textView5;
    TextView textView6;

    public interface OnNameSetListener {
        void setName(String str);
    }

    @Nullable
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.foodmenufragment2_foodprice, container, false);
        this.textView = (TextView) view.findViewById(R.id.Istpricebutton);
        this.textView2 = (TextView) view.findViewById(R.id.Secondpricebutton);
        this.textView3 = (TextView) view.findViewById(R.id.Thirdpricebutton);
        this.textView4 = (TextView) view.findViewById(R.id.Fourthpricebutton);
        this.textView5 = (TextView) view.findViewById(R.id.Fifthpricebutton);
        this.textView6 = (TextView) view.findViewById(R.id.Sixthpricebutton);
        this.button = (Button) view.findViewById(R.id.Istpricebutton);
        this.button2 = (Button) view.findViewById(R.id.Secondpricebutton);
        this.button3 = (Button) view.findViewById(R.id.Thirdpricebutton);
        this.button4 = (Button) view.findViewById(R.id.Fourthpricebutton);
        this.button5 = (Button) view.findViewById(R.id.Fifthpricebutton);
        this.button6 = (Button) view.findViewById(R.id.Sixthpricebutton);
        this.button.setVisibility(8);
        this.button2.setVisibility(8);
        this.button3.setVisibility(8);
        this.button4.setVisibility(8);
        this.button5.setVisibility(8);
        this.button6.setVisibility(8);
        this.button.setOnClickListener(new OnClickListener() {
            public void onClick(View v) {
                FoodpriceFragment.this.onNameSetListener.setName(FoodpriceFragment.this.textView.getText().toString());
            }
        });
        Animation in = AnimationUtils.loadAnimation(getActivity(), 17432578);
        Animation out = AnimationUtils.loadAnimation(getActivity(), 17432579);
        this.button2.setOnClickListener(new OnClickListener() {
            public void onClick(View v) {
                FoodpriceFragment.this.onNameSetListener.setName(FoodpriceFragment.this.textView2.getText().toString());
            }
        });
        this.button3.setOnClickListener(new OnClickListener() {
            public void onClick(View v) {
                FoodpriceFragment.this.onNameSetListener.setName(FoodpriceFragment.this.textView3.getText().toString());
            }
        });
        this.button4.setOnClickListener(new OnClickListener() {
            public void onClick(View v) {
                FoodpriceFragment.this.onNameSetListener.setName(FoodpriceFragment.this.textView4.getText().toString());
            }
        });
        this.button5.setOnClickListener(new OnClickListener() {
            public void onClick(View v) {
                FoodpriceFragment.this.onNameSetListener.setName(FoodpriceFragment.this.textView5.getText().toString());
            }
        });
        this.button6.setOnClickListener(new OnClickListener() {
            public void onClick(View v) {
                FoodpriceFragment.this.onNameSetListener.setName(FoodpriceFragment.this.textView6.getText().toString());
            }
        });
        return view;
    }

    public void onAttach(Activity activity) {
        super.onAttach(activity);
        try {
            this.onNameSetListener = (OnNameSetListener) activity;
        } catch (Exception e) {
        }
    }

    public void Datachange(int i) {
        Resources resourcez = getResources();
        this.button.setText(resourcez.getStringArray(R.array.amount)[i]);
        this.button.setVisibility(0);
        this.button2.setText(resourcez.getStringArray(R.array.amount2)[i]);
        this.button2.setVisibility(0);
        this.button3.setText(resourcez.getStringArray(R.array.amount3)[i]);
        this.button3.setVisibility(0);
        this.button4.setText(resourcez.getStringArray(R.array.amount4)[i]);
        this.button4.setVisibility(0);
        this.button5.setText(resourcez.getStringArray(R.array.amount5)[i]);
        this.button5.setVisibility(0);
        this.button6.setText(resourcez.getStringArray(R.array.amount6)[i]);
        this.button6.setVisibility(0);
    }
}
