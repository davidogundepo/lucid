package com.icdatofcusgmail.lucidfood;

import android.content.Intent;
import android.net.wifi.WifiManager;
import android.os.Build.VERSION;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import com.facebook.common.util.ByteConstants;

public class VendorActivity extends AppCompatActivity implements OnItemClickListener, Communicator {
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_vendor);
        ((WifiManager) getSystemService("wifi")).setWifiEnabled(true);
        startService(new Intent(this, FoodServicing.class));
        Log.d("VendorActivity", "onCreate invoked");
        getWindow().setFlags(ByteConstants.KB, ByteConstants.KB);
        getWindow().addFlags(128);
        if (VERSION.SDK_INT >= 21) {
            getWindow().setStatusBarColor(getResources().getColor(17170445));
        }
    }

    public void OCAddorRemove(View view) {
        new AddorRemove().show(getFragmentManager(), "AddorRemove");
    }

    public void OCDynamicPlateCount(View view) {
        new DynamicPlateCount().show(getFragmentManager(), "DynamicPlateCount");
    }

    public void onItemClick(AdapterView<?> adapterView, View view, int position, long id) {
    }

    public void respond(int i) {
    }

    public void FoodMenuFragmentsRespond(int joseph) {
        ((VendorFragment) getFragmentManager().findFragmentById(R.id.displayAddorRemoveDialogue)).displayGridView(joseph);
    }

    public void GetMeNextActivity(View view) {
        startActivity(new Intent(this, LoginActivity.class));
    }

    protected void onStart() {
        super.onStart();
        Log.d("VendorActivity", "onStart invoked");
    }

    protected void onResume() {
        super.onResume();
        Log.d("VendorActivity", "onResume invoked");
    }

    protected void onPause() {
        super.onPause();
        Log.d("VendorActivity", "onPause invoked");
    }

    protected void onRestart() {
        super.onRestart();
        Log.d("VendorActivity", "onRestart invoked");
    }

    protected void onDestroy() {
        super.onDestroy();
        Log.d("VendorActivity", "onDestroy invoked");
    }
}
