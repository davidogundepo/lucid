package com.alimuzaffar.lib.widgets;

import android.animation.Animator;
import android.animation.Animator.AnimatorListener;
import android.animation.AnimatorSet;
import android.animation.ValueAnimator;
import android.animation.ValueAnimator.AnimatorUpdateListener;
import android.annotation.TargetApi;
import android.content.Context;
import android.content.res.ColorStateList;
import android.content.res.TypedArray;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Rect;
import android.graphics.Typeface;
import android.os.Build.VERSION;
import android.support.v7.widget.AppCompatEditText;
import android.support.v7.widget.ViewUtils;
import android.text.TextUtils;
import android.util.AttributeSet;
import android.util.TypedValue;
import android.view.animation.DecelerateInterpolator;
import android.view.animation.OvershootInterpolator;
import android.widget.TextView.BufferType;
import droidninja.filepicker.R;
import java.util.ArrayList;
import java.util.Collection;

public class AnimatedEditText extends AppCompatEditText {
    public static final String XML_NAMESPACE_ANDROID = "http://schemas.android.com/apk/res/android";
    private float mAnimBottomOffset = 0.0f;
    private Paint mAnimPaint;
    private float mAnimRightOffset = 0.0f;
    private AnimatorSet mAnimSet = null;
    private boolean mAnimateCursor = true;
    private boolean mAnimated = true;
    private boolean mAnimatedClear = true;
    private AnimationType mAnimationType = AnimationType.BOTTOM_UP;
    Collection<Animator> mAnimationsToPlay = new ArrayList();
    private Paint mCursorPaint;
    private float mCursorX = 0.0f;
    private int mEnd = 0;
    private float mFixedBottomOffset = 0.0f;
    private float mFixedRightOffset = 0.0f;
    private String mMask = null;
    private StringBuilder mMaskChars = null;
    private int mOriginalAlpha;
    private ColorStateList mOriginalTextColors;
    private Paint mPaint;
    private boolean mShouldAnimateCursor = false;
    private int mStart = 0;

    abstract class AnimationEndListener implements AnimatorListener {
        AnimationEndListener() {
        }

        public void onAnimationStart(Animator animation) {
        }

        public void onAnimationCancel(Animator animation) {
        }

        public void onAnimationRepeat(Animator animation) {
        }
    }

    static /* synthetic */ class AnonymousClass11 {
        static final /* synthetic */ int[] $SwitchMap$com$alimuzaffar$lib$widgets$AnimatedEditText$AnimationType = new int[AnimationType.values().length];

        static {
            try {
                $SwitchMap$com$alimuzaffar$lib$widgets$AnimatedEditText$AnimationType[AnimationType.POP_IN.ordinal()] = 1;
            } catch (NoSuchFieldError e) {
            }
            try {
                $SwitchMap$com$alimuzaffar$lib$widgets$AnimatedEditText$AnimationType[AnimationType.BOTTOM_UP.ordinal()] = 2;
            } catch (NoSuchFieldError e2) {
            }
            try {
                $SwitchMap$com$alimuzaffar$lib$widgets$AnimatedEditText$AnimationType[AnimationType.RIGHT_TO_LEFT.ordinal()] = 3;
            } catch (NoSuchFieldError e3) {
            }
            try {
                $SwitchMap$com$alimuzaffar$lib$widgets$AnimatedEditText$AnimationType[AnimationType.MIDDLE_UP.ordinal()] = 4;
            } catch (NoSuchFieldError e4) {
            }
        }
    }

    public enum AnimationType {
        RIGHT_TO_LEFT,
        BOTTOM_UP,
        MIDDLE_UP,
        POP_IN,
        NONE
    }

    public AnimatedEditText(Context context) {
        super(context);
        init(context, null);
    }

    public AnimatedEditText(Context context, AttributeSet attrs) {
        super(context, attrs);
        init(context, attrs);
    }

    public AnimatedEditText(Context context, AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);
        init(context, attrs);
    }

    private void init(Context context, AttributeSet attrs) {
        boolean z = false;
        TypedArray ta = context.obtainStyledAttributes(attrs, R.styleable.AnimatedEditText, 0, 0);
        try {
            TypedValue outValue = new TypedValue();
            ta.getValue(R.styleable.AnimatedEditText_animationType, outValue);
            AnimationType animationType;
            if (outValue.data == 0) {
                animationType = AnimationType.BOTTOM_UP;
                this.mAnimationType = animationType;
                setAnimationType(animationType);
            } else if (outValue.data == 1) {
                animationType = AnimationType.RIGHT_TO_LEFT;
                this.mAnimationType = animationType;
                setAnimationType(animationType);
            } else if (outValue.data == 2) {
                animationType = AnimationType.MIDDLE_UP;
                this.mAnimationType = animationType;
                setAnimationType(animationType);
            } else if (outValue.data == 3) {
                animationType = AnimationType.POP_IN;
                this.mAnimationType = animationType;
                setAnimationType(animationType);
            } else if (outValue.data == -1) {
                animationType = AnimationType.NONE;
                this.mAnimationType = animationType;
                setAnimationType(animationType);
            }
            this.mMask = ta.getString(R.styleable.AnimatedEditText_textMask);
            this.mAnimatedClear = ta.getBoolean(R.styleable.AnimatedEditText_animateTextClear, this.mAnimatedClear);
            this.mAnimateCursor = ta.getBoolean(R.styleable.AnimatedEditText_animateCursor, this.mAnimateCursor);
            if (this.mAnimateCursor && VERSION.SDK_INT >= 16 && !ViewUtils.isLayoutRtl(this)) {
                z = true;
            }
            this.mAnimateCursor = z;
            if ((getInputType() & 128) == 128 && TextUtils.isEmpty(this.mMask)) {
                this.mMask = "\u25cf";
            } else if ((getInputType() & 16) == 16 && TextUtils.isEmpty(this.mMask)) {
                this.mMask = "\u25cf";
            }
            if (!TextUtils.isEmpty(this.mMask)) {
                this.mMaskChars = getMaskChars();
            }
            this.mCursorPaint = new Paint(1);
            outValue = new TypedValue();
            context.getTheme().resolveAttribute(R.attr.colorControlActivated, outValue, true);
            this.mCursorPaint.setColor(outValue.data);
            this.mCursorPaint.setStrokeWidth(context.getResources().getDisplayMetrics().density * 2.0f);
        } finally {
            ta.recycle();
        }
    }

    public void setTextAnimated(boolean animated) {
        this.mAnimated = animated;
        if (animated) {
            setTextColor(0);
        } else if (this.mOriginalTextColors != null) {
            setTextColor(this.mOriginalTextColors);
        }
    }

    public void setAnimationType(AnimationType animationType) {
        if (this.mAnimationType == null || animationType == AnimationType.NONE) {
            this.mAnimationType = AnimationType.NONE;
            setTextAnimated(false);
            return;
        }
        this.mAnimationType = animationType;
    }

    @TargetApi(16)
    public void setCursorAnimated(boolean animated) {
        boolean z = animated && VERSION.SDK_INT >= 16 && !ViewUtils.isLayoutRtl(this);
        this.mAnimateCursor = z;
    }

    protected void onSizeChanged(int w, int h, int oldw, int oldh) {
        super.onSizeChanged(w, h, oldw, oldh);
        setupPaint();
    }

    private void setupPaint() {
        this.mPaint = new Paint(getPaint());
        this.mAnimPaint = new Paint(getPaint());
        this.mOriginalTextColors = getTextColors();
        if (!TextUtils.isEmpty(this.mMask)) {
            this.mPaint.setTypeface(Typeface.MONOSPACE);
            this.mAnimPaint.setTypeface(Typeface.MONOSPACE);
        }
        if (this.mOriginalTextColors != null) {
            this.mPaint.setColor(this.mOriginalTextColors.getDefaultColor());
            this.mAnimPaint.setColor(this.mOriginalTextColors.getDefaultColor());
            this.mOriginalAlpha = this.mAnimPaint.getAlpha();
        }
        if (this.mAnimationType != AnimationType.NONE) {
            setTextColor(0);
        }
        if (!TextUtils.isEmpty(getText())) {
            this.mStart = 0;
            this.mEnd = getText().length();
            invalidate();
        }
    }

    protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);
        if (this.mAnimated) {
            boolean rightAligned;
            boolean leftAligned;
            updateColorsForState();
            if ((getGravity() & 5) == 5 || (getGravity() & 8388613) == 8388613) {
                rightAligned = true;
            } else {
                rightAligned = false;
            }
            if ((getGravity() & 3) == 3 || (getGravity() & 8388611) == 8388611) {
                leftAligned = true;
            } else {
                leftAligned = false;
            }
            if (rightAligned) {
                drawGravityRight(canvas);
            } else if (leftAligned) {
                drawGravityLeft(canvas);
            } else {
                drawGravityCenterHorizontal(canvas);
            }
        }
    }

    private void drawGravityLeft(Canvas canvas) {
        String fixedText = getFixedText();
        float fixedTextWidth = this.mPaint.measureText(fixedText);
        float startX = (float) getCompoundPaddingLeft();
        drawFixedText(canvas, fixedText, startX, (float) getLineBounds(0, null));
        drawAnimText(canvas, getFullText(), startX + fixedTextWidth, (float) getLineBounds(0, null));
        drawCursor(canvas, startX + fixedTextWidth);
    }

    private void drawGravityRight(Canvas canvas) {
        canvas.translate((float) getScrollX(), 0.0f);
        String fixedText = getFixedText();
        float fixedTextWidth = this.mPaint.measureText(fixedText);
        float animCharWidth = this.mPaint.measureText(getAnimText());
        float startX = (float) (getWidth() - getCompoundPaddingRight());
        drawFixedText(canvas, fixedText, startX - (fixedTextWidth + animCharWidth), (float) getLineBounds(0, null));
        drawAnimText(canvas, getFullText(), startX - animCharWidth, (float) getLineBounds(0, null));
    }

    private void drawGravityCenterHorizontal(Canvas canvas) {
        canvas.translate((float) getScrollX(), 0.0f);
        String fixedText = getFixedText();
        float fixedTextWidth = this.mPaint.measureText(fixedText);
        float animCharWidth = this.mPaint.measureText(getAnimText());
        float fullTexWidth = fixedTextWidth + animCharWidth;
        float startXAnim = (((float) (getWidth() / 2)) + (fullTexWidth / 2.0f)) - animCharWidth;
        drawFixedText(canvas, fixedText, ((float) (getWidth() / 2)) - (fullTexWidth / 2.0f), (float) getLineBounds(0, null));
        drawAnimText(canvas, getFullText(), startXAnim, (float) getLineBounds(0, null));
        drawCursor(canvas, startXAnim);
    }

    private void drawFixedText(Canvas canvas, String fixedText, float startX, float bottomX) {
        canvas.drawText(fixedText, this.mFixedRightOffset + startX, this.mFixedBottomOffset + bottomX, this.mPaint);
    }

    private void drawAnimText(Canvas canvas, CharSequence animText, float startX, float bottomX) {
        canvas.drawText(animText, this.mStart, this.mEnd, startX + this.mAnimRightOffset, bottomX + this.mAnimBottomOffset, this.mAnimPaint);
    }

    private void drawCursor(Canvas canvas, float startX) {
        if (this.mAnimateCursor && isFocused() && VERSION.SDK_INT >= 16 && !isCursorVisible()) {
            float cursorStartX = startX + this.mCursorX;
            canvas.drawLine(cursorStartX, (float) getCompoundPaddingTop(), cursorStartX, ((float) getHeight()) - (getContext().getResources().getDisplayMetrics().scaledDensity * 11.0f), this.mCursorPaint);
        }
    }

    private void updateColorsForState() {
        if (this.mOriginalTextColors != null) {
            int[] states = new int[3];
            states[0] = isEnabled() ? 16842910 : -16842910;
            states[1] = isFocused() ? 16842908 : -16842908;
            states[2] = isSelected() ? 16842913 : -16842913;
            int color = this.mOriginalTextColors.getColorForState(states, this.mOriginalTextColors.getDefaultColor());
            this.mPaint.setColor(color);
            int alpha = this.mAnimPaint.getAlpha();
            this.mAnimPaint.setColor(color);
            this.mAnimPaint.setAlpha(alpha);
        }
    }

    private CharSequence getFullText() {
        if (TextUtils.isEmpty(this.mMask)) {
            return getText();
        }
        return getMaskChars();
    }

    private String getFixedText() {
        if (TextUtils.isEmpty(this.mMask)) {
            return TextUtils.substring(getText(), 0, this.mStart);
        }
        return TextUtils.substring(getMaskChars(), 0, this.mStart);
    }

    private String getAnimText() {
        if (TextUtils.isEmpty(this.mMask)) {
            return TextUtils.substring(getText(), this.mStart, this.mEnd);
        }
        return TextUtils.substring(getMaskChars(), this.mStart, this.mEnd);
    }

    private StringBuilder getMaskChars() {
        if (this.mMaskChars == null) {
            this.mMaskChars = new StringBuilder();
        }
        int textLength = getText().length();
        while (this.mMaskChars.length() != textLength) {
            if (this.mMaskChars.length() < textLength) {
                this.mMaskChars.append(this.mMask);
            } else {
                this.mMaskChars.deleteCharAt(this.mMaskChars.length() - 1);
            }
        }
        return this.mMaskChars;
    }

    public void setText(CharSequence text, final BufferType type) {
        if (this.mAnimated && this.mAnimatedClear && this.mPaint != null && TextUtils.isEmpty(text)) {
            AnimationEndListener endListener = new AnimationEndListener() {
                public void onAnimationEnd(Animator animation) {
                    super.setText(null, type);
                }
            };
            this.mStart = 0;
            this.mEnd = getText().length();
            switch (AnonymousClass11.$SwitchMap$com$alimuzaffar$lib$widgets$AnimatedEditText$AnimationType[this.mAnimationType.ordinal()]) {
                case R.styleable.View_android_focusable /*1*/:
                    animatePopIn(true, endListener);
                    return;
                case R.styleable.View_paddingStart /*2*/:
                    animateInFromBottom(true, endListener);
                    return;
                case R.styleable.View_paddingEnd /*3*/:
                    animateInFromRight(true, endListener);
                    return;
                case R.styleable.View_theme /*4*/:
                    animateInFromMiddle(true, endListener);
                    return;
                default:
                    super.setText(text, type);
                    return;
            }
        }
        super.setText(text, type);
    }

    protected void onFocusChanged(boolean focused, int direction, Rect previouslyFocusedRect) {
        super.onFocusChanged(focused, direction, previouslyFocusedRect);
        boolean z = this.mAnimateCursor && focused;
        this.mShouldAnimateCursor = z;
    }

    protected void onTextChanged(CharSequence text, int start, int lengthBefore, int lengthAfter) {
        super.onTextChanged(text, start, lengthBefore, lengthAfter);
        if (!this.mAnimated) {
            return;
        }
        if (this.mPaint == null) {
            invalidate();
            return;
        }
        String added = TextUtils.substring(text, start, start + lengthAfter);
        int textLength = text.length();
        if (lengthAfter != 1 || !added.equals(" ")) {
            if (lengthBefore == lengthAfter) {
                this.mStart = textLength - 1;
                this.mEnd = textLength;
            } else if (lengthBefore >= lengthAfter || textLength != start + lengthAfter) {
                this.mStart = 0;
                this.mEnd = text.length();
            } else {
                if (this.mAnimSet != null) {
                    this.mAnimSet.cancel();
                    this.mAnimSet = null;
                }
                if (lengthBefore == 0) {
                    this.mStart = start;
                    this.mEnd = start + lengthAfter;
                } else {
                    this.mStart = textLength - 1;
                    this.mEnd = textLength;
                }
                switch (AnonymousClass11.$SwitchMap$com$alimuzaffar$lib$widgets$AnimatedEditText$AnimationType[this.mAnimationType.ordinal()]) {
                    case R.styleable.View_android_focusable /*1*/:
                        animatePopIn();
                        return;
                    case R.styleable.View_paddingStart /*2*/:
                        animateInFromBottom();
                        return;
                    case R.styleable.View_paddingEnd /*3*/:
                        animateInFromRight();
                        return;
                    case R.styleable.View_theme /*4*/:
                        animateInFromMiddle();
                        return;
                    default:
                        this.mStart = 0;
                        this.mEnd = text.length();
                        invalidate();
                        return;
                }
            }
        }
    }

    private void animateInFromBottom() {
        animateInFromBottom(false, null);
    }

    private void animateInFromBottom(boolean reverse, AnimationEndListener listener) {
        float start = reverse ? 0.0f : (float) ((getHeight() - getCompoundPaddingBottom()) - getCompoundPaddingTop());
        float end = reverse ? (float) ((getHeight() - getCompoundPaddingBottom()) - getCompoundPaddingTop()) : 0.0f;
        ValueAnimator animUp = ValueAnimator.ofFloat(new float[]{start, end});
        animUp.setDuration(300);
        animUp.setInterpolator(new OvershootInterpolator());
        animUp.addUpdateListener(new AnimatorUpdateListener() {
            public void onAnimationUpdate(ValueAnimator animation) {
                AnimatedEditText.this.mAnimBottomOffset = ((Float) animation.getAnimatedValue()).floatValue();
                AnimatedEditText.this.invalidate();
            }
        });
        int alphaStart = reverse ? this.mOriginalAlpha : 0;
        int alphaEnd = reverse ? 0 : this.mOriginalAlpha;
        ValueAnimator animAlpha = ValueAnimator.ofInt(new int[]{alphaStart, alphaEnd});
        animAlpha.setDuration(reverse ? 100 : 300);
        animAlpha.addUpdateListener(new AnimatorUpdateListener() {
            public void onAnimationUpdate(ValueAnimator animation) {
                AnimatedEditText.this.mAnimPaint.setAlpha(((Integer) animation.getAnimatedValue()).intValue());
            }
        });
        this.mAnimSet = new AnimatorSet();
        if (listener != null) {
            this.mAnimSet.addListener(listener);
        }
        this.mAnimationsToPlay.clear();
        this.mAnimationsToPlay.add(animAlpha);
        this.mAnimationsToPlay.add(animUp);
        if (this.mShouldAnimateCursor) {
            this.mAnimationsToPlay.add(animateMoveCursor(reverse));
        }
        this.mAnimSet.playTogether(this.mAnimationsToPlay);
        this.mAnimSet.start();
    }

    private void animateInFromRight() {
        animateInFromRight(false, null);
    }

    private void animateInFromRight(boolean reverse, AnimationEndListener listener) {
        float end = 0.0f;
        float start = reverse ? 0.0f : (float) (getWidth() + (getContext().getResources().getDisplayMetrics().widthPixels - getWidth()));
        if (reverse) {
            end = (float) (getWidth() + (getContext().getResources().getDisplayMetrics().widthPixels - getWidth()));
        }
        ValueAnimator va = ValueAnimator.ofFloat(new float[]{start, end});
        va.setDuration(300);
        va.setInterpolator(new DecelerateInterpolator());
        va.addUpdateListener(new AnimatorUpdateListener() {
            public void onAnimationUpdate(ValueAnimator animation) {
                AnimatedEditText.this.mAnimRightOffset = ((Float) animation.getAnimatedValue()).floatValue();
                AnimatedEditText.this.invalidate();
            }
        });
        this.mAnimSet = new AnimatorSet();
        if (listener != null) {
            this.mAnimSet.addListener(listener);
        }
        this.mAnimationsToPlay.clear();
        this.mAnimationsToPlay.add(va);
        if (this.mShouldAnimateCursor) {
            this.mAnimationsToPlay.add(animateMoveCursor(reverse));
        }
        this.mAnimSet.playTogether(this.mAnimationsToPlay);
        this.mAnimSet.start();
    }

    private void animateInFromMiddle() {
        animateInFromMiddle(false, null);
    }

    private void animateInFromMiddle(boolean reverse, AnimationEndListener listener) {
        float endMiddle;
        final float textWidth = this.mPaint.measureText(TextUtils.substring(getText(), 0, this.mStart));
        float startMiddle = reverse ? textWidth : (float) (getWidth() / 2);
        if (reverse) {
            endMiddle = (float) (getWidth() / 2);
        } else {
            endMiddle = textWidth;
        }
        ValueAnimator animMiddle = ValueAnimator.ofFloat(new float[]{startMiddle, endMiddle});
        animMiddle.setInterpolator(new DecelerateInterpolator());
        animMiddle.setDuration(200);
        animMiddle.addUpdateListener(new AnimatorUpdateListener() {
            public void onAnimationUpdate(ValueAnimator animation) {
                AnimatedEditText.this.mAnimRightOffset = ((Float) animation.getAnimatedValue()).floatValue();
                AnimatedEditText.this.mAnimRightOffset = AnimatedEditText.this.mAnimRightOffset - textWidth;
                AnimatedEditText.this.invalidate();
            }
        });
        float startUp = reverse ? 0.0f : (float) ((getHeight() - getCompoundPaddingBottom()) - getCompoundPaddingTop());
        float endUp = reverse ? (float) ((getHeight() - getCompoundPaddingBottom()) - getCompoundPaddingTop()) : 0.0f;
        ValueAnimator animUp = ValueAnimator.ofFloat(new float[]{startUp, endUp});
        animUp.setDuration(200);
        animUp.addUpdateListener(new AnimatorUpdateListener() {
            public void onAnimationUpdate(ValueAnimator animation) {
                AnimatedEditText.this.mAnimBottomOffset = ((Float) animation.getAnimatedValue()).floatValue();
                AnimatedEditText.this.invalidate();
            }
        });
        int alphaStart = reverse ? this.mOriginalAlpha : 0;
        int alphaEnd = reverse ? 0 : this.mOriginalAlpha;
        ValueAnimator animAlpha = ValueAnimator.ofInt(new int[]{alphaStart, alphaEnd});
        animAlpha.setDuration(300);
        animAlpha.addUpdateListener(new AnimatorUpdateListener() {
            public void onAnimationUpdate(ValueAnimator animation) {
                AnimatedEditText.this.mAnimPaint.setAlpha(((Integer) animation.getAnimatedValue()).intValue());
            }
        });
        this.mAnimSet = new AnimatorSet();
        if (listener != null) {
            this.mAnimSet.addListener(listener);
        }
        this.mAnimationsToPlay.clear();
        this.mAnimationsToPlay.add(animUp);
        this.mAnimationsToPlay.add(animAlpha);
        this.mAnimationsToPlay.add(animMiddle);
        if (this.mShouldAnimateCursor) {
            this.mAnimationsToPlay.add(animateMoveCursor(reverse));
        }
        this.mAnimSet.playTogether(this.mAnimationsToPlay);
        this.mAnimSet.start();
    }

    private void animatePopIn() {
        animatePopIn(false, null);
    }

    private void animatePopIn(boolean reverse, AnimationEndListener listener) {
        float start;
        float end = 1.0f;
        if (reverse) {
            start = getPaint().getTextSize();
        } else {
            start = 1.0f;
        }
        if (!reverse) {
            end = getPaint().getTextSize();
        }
        ValueAnimator va = ValueAnimator.ofFloat(new float[]{start, end});
        va.setInterpolator(new OvershootInterpolator());
        va.addUpdateListener(new AnimatorUpdateListener() {
            public void onAnimationUpdate(ValueAnimator animation) {
                AnimatedEditText.this.mAnimPaint.setTextSize(((Float) animation.getAnimatedValue()).floatValue());
                AnimatedEditText.this.invalidate();
            }
        });
        this.mAnimSet = new AnimatorSet();
        if (listener != null) {
            this.mAnimSet.addListener(listener);
        }
        this.mAnimationsToPlay.clear();
        this.mAnimationsToPlay.add(va);
        if (this.mShouldAnimateCursor) {
            this.mAnimationsToPlay.add(animateMoveCursor(reverse));
        }
        this.mAnimSet.playTogether(this.mAnimationsToPlay);
        this.mAnimSet.setDuration(200);
        this.mAnimSet.start();
    }

    @TargetApi(16)
    private ValueAnimator animateMoveCursor(boolean reverse) {
        float start;
        float end = 0.0f;
        if (reverse) {
            start = getPaint().measureText(getAnimText());
        } else {
            start = 0.0f;
        }
        if (!reverse) {
            end = getPaint().measureText(getAnimText());
        }
        ValueAnimator va = ValueAnimator.ofFloat(new float[]{start, end});
        va.addUpdateListener(new AnimatorUpdateListener() {
            public void onAnimationUpdate(ValueAnimator animation) {
                AnimatedEditText.this.mCursorX = ((Float) animation.getAnimatedValue()).floatValue() + ((float) AnimatedEditText.this.getCompoundPaddingLeft());
            }
        });
        if (isCursorVisible()) {
            va.addListener(new AnimationEndListener() {
                public void onAnimationStart(Animator animation) {
                    AnimatedEditText.this.setCursorVisible(false);
                }

                public void onAnimationEnd(Animator animation) {
                    AnimatedEditText.this.setCursorVisible(true);
                    AnimatedEditText.this.setSelection(AnimatedEditText.this.getText().length());
                }
            });
        }
        return va;
    }
}
