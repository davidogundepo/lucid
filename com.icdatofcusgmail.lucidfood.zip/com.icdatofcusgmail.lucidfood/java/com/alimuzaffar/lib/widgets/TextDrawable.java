package com.alimuzaffar.lib.widgets;

import android.graphics.Canvas;
import android.graphics.ColorFilter;
import android.graphics.Paint;
import android.graphics.Rect;
import android.graphics.drawable.Drawable;
import android.text.Editable;
import android.text.TextWatcher;
import android.widget.TextView;
import com.facebook.imageutils.JfifUtil;
import java.lang.ref.WeakReference;

public class TextDrawable extends Drawable implements TextWatcher {
    private boolean mBindToViewPaint;
    private boolean mFitTextEnabled;
    private Rect mHeightBounds;
    private boolean mInitFitText;
    private Paint mPaint;
    private float mPrevTextSize;
    private String mText;
    private WeakReference<TextView> ref;

    public TextDrawable(Paint paint, String s) {
        this.mBindToViewPaint = false;
        this.mPrevTextSize = 0.0f;
        this.mInitFitText = false;
        this.mFitTextEnabled = false;
        this.mText = s;
        this.mPaint = new Paint(paint);
        this.mHeightBounds = new Rect();
        init();
    }

    public TextDrawable(TextView tv, String initialText, boolean bindToViewsText, boolean bindToViewsPaint) {
        this(tv.getPaint(), initialText);
        this.ref = new WeakReference(tv);
        if (bindToViewsText || bindToViewsPaint) {
            if (bindToViewsText) {
                tv.addTextChangedListener(this);
            }
            this.mBindToViewPaint = bindToViewsPaint;
        }
    }

    public TextDrawable(TextView tv, boolean bindToViewsText, boolean bindToViewsPaint) {
        this(tv, tv.getText().toString(), false, false);
    }

    public TextDrawable(TextView tv) {
        this(tv, false, false);
    }

    public TextDrawable(TextView tv, String s) {
        this(tv, s, false, false);
    }

    public void draw(Canvas canvas) {
        if (!this.mBindToViewPaint || this.ref.get() == null) {
            if (this.mInitFitText) {
                fitTextAndInit();
            }
            canvas.drawText(this.mText, 0.0f, (float) getBounds().height(), this.mPaint);
            return;
        }
        canvas.drawText(this.mText, 0.0f, (float) getBounds().height(), ((TextView) this.ref.get()).getPaint());
    }

    public void setAlpha(int alpha) {
        this.mPaint.setAlpha(alpha);
    }

    public void setColorFilter(ColorFilter colorFilter) {
        this.mPaint.setColorFilter(colorFilter);
    }

    public int getOpacity() {
        int alpha = this.mPaint.getAlpha();
        if (alpha == 0) {
            return -2;
        }
        if (alpha == JfifUtil.MARKER_FIRST_BYTE) {
            return -1;
        }
        return -3;
    }

    private void init() {
        Rect bounds = getBounds();
        this.mPaint.getTextBounds("1234567890ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz", 0, 1, this.mHeightBounds);
        float width = this.mPaint.measureText(this.mText);
        bounds.top = this.mHeightBounds.top;
        bounds.bottom = this.mHeightBounds.bottom;
        bounds.right = (int) width;
        bounds.left = 0;
        setBounds(bounds);
    }

    public void setPaint(Paint paint) {
        this.mPaint = new Paint(paint);
        if (!this.mFitTextEnabled || this.mInitFitText) {
            init();
        } else {
            fitTextAndInit();
        }
        invalidateSelf();
    }

    public Paint getPaint() {
        return this.mPaint;
    }

    public void setText(String text) {
        this.mText = text;
        if (!this.mFitTextEnabled || this.mInitFitText) {
            init();
        } else {
            fitTextAndInit();
        }
        invalidateSelf();
    }

    public String getText() {
        return this.mText;
    }

    public void beforeTextChanged(CharSequence s, int start, int count, int after) {
    }

    public void onTextChanged(CharSequence s, int start, int before, int count) {
    }

    public void afterTextChanged(Editable s) {
        setText(s.toString());
    }

    public void setFillText(boolean fitText) {
        this.mFitTextEnabled = fitText;
        if (fitText) {
            this.mPrevTextSize = this.mPaint.getTextSize();
            if (this.ref.get() == null) {
                return;
            }
            if (((TextView) this.ref.get()).getWidth() > 0) {
                fitTextAndInit();
                return;
            } else {
                this.mInitFitText = true;
                return;
            }
        }
        if (this.mPrevTextSize > 0.0f) {
            this.mPaint.setTextSize(this.mPrevTextSize);
        }
        init();
    }

    private void fitTextAndInit() {
        this.mPaint.setTextSize(this.mPaint.getTextSize() * (((float) ((TextView) this.ref.get()).getWidth()) / this.mPaint.measureText(this.mText)));
        this.mInitFitText = false;
        init();
    }
}
