package com.facebook.drawee;

public final class R {

    public static final class attr {
        public static final int actualImageScaleType = 2130772210;
        public static final int actualImageUri = 2130772262;
        public static final int backgroundImage = 2130772211;
        public static final int fadeDuration = 2130772199;
        public static final int failureImage = 2130772205;
        public static final int failureImageScaleType = 2130772206;
        public static final int overlayImage = 2130772212;
        public static final int placeholderImage = 2130772201;
        public static final int placeholderImageScaleType = 2130772202;
        public static final int pressedStateOverlayImage = 2130772213;
        public static final int progressBarAutoRotateInterval = 2130772209;
        public static final int progressBarImage = 2130772207;
        public static final int progressBarImageScaleType = 2130772208;
        public static final int retryImage = 2130772203;
        public static final int retryImageScaleType = 2130772204;
        public static final int roundAsCircle = 2130772214;
        public static final int roundBottomLeft = 2130772219;
        public static final int roundBottomRight = 2130772218;
        public static final int roundTopLeft = 2130772216;
        public static final int roundTopRight = 2130772217;
        public static final int roundWithOverlayColor = 2130772220;
        public static final int roundedCornerRadius = 2130772215;
        public static final int roundingBorderColor = 2130772222;
        public static final int roundingBorderPadding = 2130772223;
        public static final int roundingBorderWidth = 2130772221;
        public static final int viewAspectRatio = 2130772200;
    }

    public static final class id {
        public static final int center = 2131689515;
        public static final int centerCrop = 2131689532;
        public static final int centerInside = 2131689533;
        public static final int fitCenter = 2131689534;
        public static final int fitEnd = 2131689535;
        public static final int fitStart = 2131689536;
        public static final int fitXY = 2131689537;
        public static final int focusCrop = 2131689538;
        public static final int none = 2131689492;
    }

    public static final class styleable {
        public static final int[] GenericDraweeHierarchy = new int[]{droidninja.filepicker.R.attr.fadeDuration, droidninja.filepicker.R.attr.viewAspectRatio, droidninja.filepicker.R.attr.placeholderImage, droidninja.filepicker.R.attr.placeholderImageScaleType, droidninja.filepicker.R.attr.retryImage, droidninja.filepicker.R.attr.retryImageScaleType, droidninja.filepicker.R.attr.failureImage, droidninja.filepicker.R.attr.failureImageScaleType, droidninja.filepicker.R.attr.progressBarImage, droidninja.filepicker.R.attr.progressBarImageScaleType, droidninja.filepicker.R.attr.progressBarAutoRotateInterval, droidninja.filepicker.R.attr.actualImageScaleType, droidninja.filepicker.R.attr.backgroundImage, droidninja.filepicker.R.attr.overlayImage, droidninja.filepicker.R.attr.pressedStateOverlayImage, droidninja.filepicker.R.attr.roundAsCircle, droidninja.filepicker.R.attr.roundedCornerRadius, droidninja.filepicker.R.attr.roundTopLeft, droidninja.filepicker.R.attr.roundTopRight, droidninja.filepicker.R.attr.roundBottomRight, droidninja.filepicker.R.attr.roundBottomLeft, droidninja.filepicker.R.attr.roundWithOverlayColor, droidninja.filepicker.R.attr.roundingBorderWidth, droidninja.filepicker.R.attr.roundingBorderColor, droidninja.filepicker.R.attr.roundingBorderPadding};
        public static final int GenericDraweeHierarchy_actualImageScaleType = 11;
        public static final int GenericDraweeHierarchy_backgroundImage = 12;
        public static final int GenericDraweeHierarchy_fadeDuration = 0;
        public static final int GenericDraweeHierarchy_failureImage = 6;
        public static final int GenericDraweeHierarchy_failureImageScaleType = 7;
        public static final int GenericDraweeHierarchy_overlayImage = 13;
        public static final int GenericDraweeHierarchy_placeholderImage = 2;
        public static final int GenericDraweeHierarchy_placeholderImageScaleType = 3;
        public static final int GenericDraweeHierarchy_pressedStateOverlayImage = 14;
        public static final int GenericDraweeHierarchy_progressBarAutoRotateInterval = 10;
        public static final int GenericDraweeHierarchy_progressBarImage = 8;
        public static final int GenericDraweeHierarchy_progressBarImageScaleType = 9;
        public static final int GenericDraweeHierarchy_retryImage = 4;
        public static final int GenericDraweeHierarchy_retryImageScaleType = 5;
        public static final int GenericDraweeHierarchy_roundAsCircle = 15;
        public static final int GenericDraweeHierarchy_roundBottomLeft = 20;
        public static final int GenericDraweeHierarchy_roundBottomRight = 19;
        public static final int GenericDraweeHierarchy_roundTopLeft = 17;
        public static final int GenericDraweeHierarchy_roundTopRight = 18;
        public static final int GenericDraweeHierarchy_roundWithOverlayColor = 21;
        public static final int GenericDraweeHierarchy_roundedCornerRadius = 16;
        public static final int GenericDraweeHierarchy_roundingBorderColor = 23;
        public static final int GenericDraweeHierarchy_roundingBorderPadding = 24;
        public static final int GenericDraweeHierarchy_roundingBorderWidth = 22;
        public static final int GenericDraweeHierarchy_viewAspectRatio = 1;
        public static final int[] SimpleDraweeView;
        public static final int SimpleDraweeView_actualImageUri = 0;

        static {
            int[] iArr = new int[GenericDraweeHierarchy_viewAspectRatio];
            iArr[GenericDraweeHierarchy_fadeDuration] = droidninja.filepicker.R.attr.actualImageUri;
            SimpleDraweeView = iArr;
        }
    }
}
