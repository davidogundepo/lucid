package com.facebook.drawee.generic;

import android.content.res.Resources;
import android.graphics.ColorFilter;
import android.graphics.Matrix;
import android.graphics.PointF;
import android.graphics.RectF;
import android.graphics.drawable.Animatable;
import android.graphics.drawable.ColorDrawable;
import android.graphics.drawable.Drawable;
import com.facebook.common.internal.Preconditions;
import com.facebook.drawee.drawable.DrawableParent;
import com.facebook.drawee.drawable.FadeDrawable;
import com.facebook.drawee.drawable.ForwardingDrawable;
import com.facebook.drawee.drawable.MatrixDrawable;
import com.facebook.drawee.drawable.ScaleTypeDrawable;
import com.facebook.drawee.drawable.ScalingUtils.ScaleType;
import com.facebook.drawee.interfaces.SettableDraweeHierarchy;
import javax.annotation.Nullable;

public class GenericDraweeHierarchy implements SettableDraweeHierarchy {
    private static final int ACTUAL_IMAGE_INDEX = 2;
    private static final int BACKGROUND_IMAGE_INDEX = 0;
    private static final int FAILURE_IMAGE_INDEX = 5;
    private static final int OVERLAY_IMAGES_INDEX = 6;
    private static final int PLACEHOLDER_IMAGE_INDEX = 1;
    private static final int PROGRESS_BAR_IMAGE_INDEX = 3;
    private static final int RETRY_IMAGE_INDEX = 4;
    private final ForwardingDrawable mActualImageWrapper;
    private final Drawable mEmptyActualImageDrawable = new ColorDrawable(BACKGROUND_IMAGE_INDEX);
    private final FadeDrawable mFadeDrawable;
    private final Resources mResources;
    @Nullable
    private RoundingParams mRoundingParams;
    private final RootDrawable mTopLevelDrawable;

    GenericDraweeHierarchy(GenericDraweeHierarchyBuilder builder) {
        this.mResources = builder.getResources();
        this.mRoundingParams = builder.getRoundingParams();
        this.mActualImageWrapper = new ForwardingDrawable(this.mEmptyActualImageDrawable);
        int numOverlays = (builder.getOverlays() != null ? builder.getOverlays().size() : PLACEHOLDER_IMAGE_INDEX) + (builder.getPressedStateOverlay() != null ? PLACEHOLDER_IMAGE_INDEX : BACKGROUND_IMAGE_INDEX);
        Drawable[] layers = new Drawable[(numOverlays + OVERLAY_IMAGES_INDEX)];
        layers[BACKGROUND_IMAGE_INDEX] = buildBranch(builder.getBackground(), null);
        layers[PLACEHOLDER_IMAGE_INDEX] = buildBranch(builder.getPlaceholderImage(), builder.getPlaceholderImageScaleType());
        layers[ACTUAL_IMAGE_INDEX] = buildActualImageBranch(this.mActualImageWrapper, builder.getActualImageScaleType(), builder.getActualImageFocusPoint(), builder.getActualImageMatrix(), builder.getActualImageColorFilter());
        layers[PROGRESS_BAR_IMAGE_INDEX] = buildBranch(builder.getProgressBarImage(), builder.getProgressBarImageScaleType());
        layers[RETRY_IMAGE_INDEX] = buildBranch(builder.getRetryImage(), builder.getRetryImageScaleType());
        layers[FAILURE_IMAGE_INDEX] = buildBranch(builder.getFailureImage(), builder.getFailureImageScaleType());
        if (numOverlays > 0) {
            int index = BACKGROUND_IMAGE_INDEX;
            if (builder.getOverlays() != null) {
                for (Drawable overlay : builder.getOverlays()) {
                    int index2 = index + PLACEHOLDER_IMAGE_INDEX;
                    layers[index + OVERLAY_IMAGES_INDEX] = buildBranch(overlay, null);
                    index = index2;
                }
            } else {
                index = PLACEHOLDER_IMAGE_INDEX;
            }
            if (builder.getPressedStateOverlay() != null) {
                layers[index + OVERLAY_IMAGES_INDEX] = buildBranch(builder.getPressedStateOverlay(), null);
            }
        }
        this.mFadeDrawable = new FadeDrawable(layers);
        this.mFadeDrawable.setTransitionDuration(builder.getFadeDuration());
        this.mTopLevelDrawable = new RootDrawable(WrappingUtils.maybeWrapWithRoundedOverlayColor(this.mFadeDrawable, this.mRoundingParams));
        this.mTopLevelDrawable.mutate();
        resetFade();
    }

    @Nullable
    private Drawable buildActualImageBranch(Drawable drawable, @Nullable ScaleType scaleType, @Nullable PointF focusPoint, @Nullable Matrix matrix, @Nullable ColorFilter colorFilter) {
        drawable.setColorFilter(colorFilter);
        return WrappingUtils.maybeWrapWithMatrix(WrappingUtils.maybeWrapWithScaleType(drawable, scaleType, focusPoint), matrix);
    }

    @Nullable
    private Drawable buildBranch(@Nullable Drawable drawable, @Nullable ScaleType scaleType) {
        return WrappingUtils.maybeWrapWithScaleType(WrappingUtils.maybeApplyLeafRounding(drawable, this.mRoundingParams, this.mResources), scaleType);
    }

    private void resetActualImages() {
        this.mActualImageWrapper.setDrawable(this.mEmptyActualImageDrawable);
    }

    private void resetFade() {
        if (this.mFadeDrawable != null) {
            this.mFadeDrawable.beginBatchMode();
            this.mFadeDrawable.fadeInAllLayers();
            fadeOutBranches();
            fadeInLayer(PLACEHOLDER_IMAGE_INDEX);
            this.mFadeDrawable.finishTransitionImmediately();
            this.mFadeDrawable.endBatchMode();
        }
    }

    private void fadeOutBranches() {
        fadeOutLayer(PLACEHOLDER_IMAGE_INDEX);
        fadeOutLayer(ACTUAL_IMAGE_INDEX);
        fadeOutLayer(PROGRESS_BAR_IMAGE_INDEX);
        fadeOutLayer(RETRY_IMAGE_INDEX);
        fadeOutLayer(FAILURE_IMAGE_INDEX);
    }

    private void fadeInLayer(int index) {
        if (index >= 0) {
            this.mFadeDrawable.fadeInLayer(index);
        }
    }

    private void fadeOutLayer(int index) {
        if (index >= 0) {
            this.mFadeDrawable.fadeOutLayer(index);
        }
    }

    private void setProgress(float progress) {
        Drawable progressBarDrawable = getParentDrawableAtIndex(PROGRESS_BAR_IMAGE_INDEX).getDrawable();
        if (progressBarDrawable != null) {
            if (progress >= 0.999f) {
                if (progressBarDrawable instanceof Animatable) {
                    ((Animatable) progressBarDrawable).stop();
                }
                fadeOutLayer(PROGRESS_BAR_IMAGE_INDEX);
            } else {
                if (progressBarDrawable instanceof Animatable) {
                    ((Animatable) progressBarDrawable).start();
                }
                fadeInLayer(PROGRESS_BAR_IMAGE_INDEX);
            }
            progressBarDrawable.setLevel(Math.round(10000.0f * progress));
        }
    }

    public Drawable getTopLevelDrawable() {
        return this.mTopLevelDrawable;
    }

    public void reset() {
        resetActualImages();
        resetFade();
    }

    public void setImage(Drawable drawable, float progress, boolean immediate) {
        drawable = WrappingUtils.maybeApplyLeafRounding(drawable, this.mRoundingParams, this.mResources);
        drawable.mutate();
        this.mActualImageWrapper.setDrawable(drawable);
        this.mFadeDrawable.beginBatchMode();
        fadeOutBranches();
        fadeInLayer(ACTUAL_IMAGE_INDEX);
        setProgress(progress);
        if (immediate) {
            this.mFadeDrawable.finishTransitionImmediately();
        }
        this.mFadeDrawable.endBatchMode();
    }

    public void setProgress(float progress, boolean immediate) {
        this.mFadeDrawable.beginBatchMode();
        setProgress(progress);
        if (immediate) {
            this.mFadeDrawable.finishTransitionImmediately();
        }
        this.mFadeDrawable.endBatchMode();
    }

    public void setFailure(Throwable throwable) {
        this.mFadeDrawable.beginBatchMode();
        fadeOutBranches();
        if (this.mFadeDrawable.getDrawable(FAILURE_IMAGE_INDEX) != null) {
            fadeInLayer(FAILURE_IMAGE_INDEX);
        } else {
            fadeInLayer(PLACEHOLDER_IMAGE_INDEX);
        }
        this.mFadeDrawable.endBatchMode();
    }

    public void setRetry(Throwable throwable) {
        this.mFadeDrawable.beginBatchMode();
        fadeOutBranches();
        if (this.mFadeDrawable.getDrawable(RETRY_IMAGE_INDEX) != null) {
            fadeInLayer(RETRY_IMAGE_INDEX);
        } else {
            fadeInLayer(PLACEHOLDER_IMAGE_INDEX);
        }
        this.mFadeDrawable.endBatchMode();
    }

    public void setControllerOverlay(@Nullable Drawable drawable) {
        this.mTopLevelDrawable.setControllerOverlay(drawable);
    }

    private DrawableParent getParentDrawableAtIndex(int index) {
        DrawableParent parent = this.mFadeDrawable.getDrawableParentForIndex(index);
        if (parent.getDrawable() instanceof MatrixDrawable) {
            parent = (MatrixDrawable) parent.getDrawable();
        }
        if (parent.getDrawable() instanceof ScaleTypeDrawable) {
            return (ScaleTypeDrawable) parent.getDrawable();
        }
        return parent;
    }

    private void setChildDrawableAtIndex(int index, @Nullable Drawable drawable) {
        if (drawable == null) {
            this.mFadeDrawable.setDrawable(index, null);
            return;
        }
        getParentDrawableAtIndex(index).setDrawable(WrappingUtils.maybeApplyLeafRounding(drawable, this.mRoundingParams, this.mResources));
    }

    private ScaleTypeDrawable getScaleTypeDrawableAtIndex(int index) {
        DrawableParent parent = getParentDrawableAtIndex(index);
        if (parent instanceof ScaleTypeDrawable) {
            return (ScaleTypeDrawable) parent;
        }
        return WrappingUtils.wrapChildWithScaleType(parent, ScaleType.FIT_XY);
    }

    private boolean hasScaleTypeDrawableAtIndex(int index) {
        return getParentDrawableAtIndex(index) instanceof ScaleTypeDrawable;
    }

    public void setFadeDuration(int durationMs) {
        this.mFadeDrawable.setTransitionDuration(durationMs);
    }

    public int getFadeDuration() {
        return this.mFadeDrawable.getTransitionDuration();
    }

    public void setActualImageFocusPoint(PointF focusPoint) {
        Preconditions.checkNotNull(focusPoint);
        getScaleTypeDrawableAtIndex(ACTUAL_IMAGE_INDEX).setFocusPoint(focusPoint);
    }

    public void setActualImageScaleType(ScaleType scaleType) {
        Preconditions.checkNotNull(scaleType);
        getScaleTypeDrawableAtIndex(ACTUAL_IMAGE_INDEX).setScaleType(scaleType);
    }

    @Nullable
    public ScaleType getActualImageScaleType() {
        if (hasScaleTypeDrawableAtIndex(ACTUAL_IMAGE_INDEX)) {
            return getScaleTypeDrawableAtIndex(ACTUAL_IMAGE_INDEX).getScaleType();
        }
        return null;
    }

    public void setActualImageColorFilter(ColorFilter colorfilter) {
        this.mActualImageWrapper.setColorFilter(colorfilter);
    }

    public void getActualImageBounds(RectF outBounds) {
        this.mActualImageWrapper.getTransformedBounds(outBounds);
    }

    public void setPlaceholderImage(@Nullable Drawable drawable) {
        setChildDrawableAtIndex(PLACEHOLDER_IMAGE_INDEX, drawable);
    }

    public void setPlaceholderImage(Drawable drawable, ScaleType scaleType) {
        setChildDrawableAtIndex(PLACEHOLDER_IMAGE_INDEX, drawable);
        getScaleTypeDrawableAtIndex(PLACEHOLDER_IMAGE_INDEX).setScaleType(scaleType);
    }

    public boolean hasPlaceholderImage() {
        return getParentDrawableAtIndex(PLACEHOLDER_IMAGE_INDEX) != null;
    }

    public void setPlaceholderImageFocusPoint(PointF focusPoint) {
        Preconditions.checkNotNull(focusPoint);
        getScaleTypeDrawableAtIndex(PLACEHOLDER_IMAGE_INDEX).setFocusPoint(focusPoint);
    }

    public void setPlaceholderImage(int resourceId) {
        setPlaceholderImage(this.mResources.getDrawable(resourceId));
    }

    public void setPlaceholderImage(int resourceId, ScaleType scaleType) {
        setPlaceholderImage(this.mResources.getDrawable(resourceId), scaleType);
    }

    public void setFailureImage(@Nullable Drawable drawable) {
        setChildDrawableAtIndex(FAILURE_IMAGE_INDEX, drawable);
    }

    public void setFailureImage(Drawable drawable, ScaleType scaleType) {
        setChildDrawableAtIndex(FAILURE_IMAGE_INDEX, drawable);
        getScaleTypeDrawableAtIndex(FAILURE_IMAGE_INDEX).setScaleType(scaleType);
    }

    public void setFailureImage(int resourceId) {
        setFailureImage(this.mResources.getDrawable(resourceId));
    }

    public void setFailureImage(int resourceId, ScaleType scaleType) {
        setFailureImage(this.mResources.getDrawable(resourceId), scaleType);
    }

    public void setRetryImage(@Nullable Drawable drawable) {
        setChildDrawableAtIndex(RETRY_IMAGE_INDEX, drawable);
    }

    public void setRetryImage(Drawable drawable, ScaleType scaleType) {
        setChildDrawableAtIndex(RETRY_IMAGE_INDEX, drawable);
        getScaleTypeDrawableAtIndex(RETRY_IMAGE_INDEX).setScaleType(scaleType);
    }

    public void setRetryImage(int resourceId) {
        setRetryImage(this.mResources.getDrawable(resourceId));
    }

    public void setRetryImage(int resourceId, ScaleType scaleType) {
        setRetryImage(this.mResources.getDrawable(resourceId), scaleType);
    }

    public void setProgressBarImage(@Nullable Drawable drawable) {
        setChildDrawableAtIndex(PROGRESS_BAR_IMAGE_INDEX, drawable);
    }

    public void setProgressBarImage(Drawable drawable, ScaleType scaleType) {
        setChildDrawableAtIndex(PROGRESS_BAR_IMAGE_INDEX, drawable);
        getScaleTypeDrawableAtIndex(PROGRESS_BAR_IMAGE_INDEX).setScaleType(scaleType);
    }

    public void setProgressBarImage(int resourceId) {
        setProgressBarImage(this.mResources.getDrawable(resourceId));
    }

    public void setProgressBarImage(int resourceId, ScaleType scaleType) {
        setProgressBarImage(this.mResources.getDrawable(resourceId), scaleType);
    }

    public void setBackgroundImage(@Nullable Drawable drawable) {
        setChildDrawableAtIndex(BACKGROUND_IMAGE_INDEX, drawable);
    }

    public void setOverlayImage(int index, @Nullable Drawable drawable) {
        boolean z = index >= 0 && index + OVERLAY_IMAGES_INDEX < this.mFadeDrawable.getNumberOfLayers();
        Preconditions.checkArgument(z, "The given index does not correspond to an overlay image.");
        setChildDrawableAtIndex(index + OVERLAY_IMAGES_INDEX, drawable);
    }

    public void setOverlayImage(@Nullable Drawable drawable) {
        setOverlayImage(BACKGROUND_IMAGE_INDEX, drawable);
    }

    public void setRoundingParams(@Nullable RoundingParams roundingParams) {
        this.mRoundingParams = roundingParams;
        WrappingUtils.updateOverlayColorRounding(this.mTopLevelDrawable, this.mRoundingParams);
        for (int i = BACKGROUND_IMAGE_INDEX; i < this.mFadeDrawable.getNumberOfLayers(); i += PLACEHOLDER_IMAGE_INDEX) {
            WrappingUtils.updateLeafRounding(getParentDrawableAtIndex(i), this.mRoundingParams, this.mResources);
        }
    }

    @Nullable
    public RoundingParams getRoundingParams() {
        return this.mRoundingParams;
    }
}
