package com.facebook.drawee.interfaces;

import android.graphics.drawable.Drawable;

public interface DraweeHierarchy {
    Drawable getTopLevelDrawable();
}
