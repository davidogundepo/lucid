package com.facebook.drawee.drawable;

import android.graphics.drawable.Drawable;

public interface CloneableDrawable {
    Drawable cloneDrawable();
}
