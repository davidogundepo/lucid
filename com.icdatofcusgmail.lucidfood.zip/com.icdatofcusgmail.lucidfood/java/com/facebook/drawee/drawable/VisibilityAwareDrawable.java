package com.facebook.drawee.drawable;

public interface VisibilityAwareDrawable {
    void setVisibilityCallback(VisibilityCallback visibilityCallback);
}
