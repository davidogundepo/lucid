package com.facebook.drawee.drawable;

public interface TransformAwareDrawable {
    void setTransformCallback(TransformCallback transformCallback);
}
