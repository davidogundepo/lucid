package com.facebook.drawee.drawable;

import android.graphics.ColorFilter;
import android.graphics.drawable.Drawable;

public class DrawableProperties {
    private static final int UNSET = -1;
    private int mAlpha = UNSET;
    private ColorFilter mColorFilter = null;
    private int mDither = UNSET;
    private int mFilterBitmap = UNSET;
    private boolean mIsSetColorFilter = false;

    public void setAlpha(int alpha) {
        this.mAlpha = alpha;
    }

    public void setColorFilter(ColorFilter colorFilter) {
        this.mColorFilter = colorFilter;
        this.mIsSetColorFilter = true;
    }

    public void setDither(boolean dither) {
        this.mDither = dither ? 1 : 0;
    }

    public void setFilterBitmap(boolean filterBitmap) {
        this.mFilterBitmap = filterBitmap ? 1 : 0;
    }

    public void applyTo(Drawable drawable) {
        boolean z = true;
        if (drawable != null) {
            if (this.mAlpha != UNSET) {
                drawable.setAlpha(this.mAlpha);
            }
            if (this.mIsSetColorFilter) {
                drawable.setColorFilter(this.mColorFilter);
            }
            if (this.mDither != UNSET) {
                boolean z2;
                if (this.mDither != 0) {
                    z2 = true;
                } else {
                    z2 = false;
                }
                drawable.setDither(z2);
            }
            if (this.mFilterBitmap != UNSET) {
                if (this.mFilterBitmap == 0) {
                    z = false;
                }
                drawable.setFilterBitmap(z);
            }
        }
    }
}
