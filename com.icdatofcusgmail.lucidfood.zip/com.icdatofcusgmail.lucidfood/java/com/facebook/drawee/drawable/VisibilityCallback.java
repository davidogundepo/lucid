package com.facebook.drawee.drawable;

public interface VisibilityCallback {
    void onDraw();

    void onVisibilityChange(boolean z);
}
