package com.facebook.cache.disk;

public interface EntryEvictionComparatorSupplier {
    EntryEvictionComparator get();
}
