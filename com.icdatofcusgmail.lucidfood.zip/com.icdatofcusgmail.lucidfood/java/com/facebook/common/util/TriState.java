package com.facebook.common.util;

import droidninja.filepicker.R;

public enum TriState {
    YES,
    NO,
    UNSET;

    static /* synthetic */ class AnonymousClass1 {
        static final /* synthetic */ int[] $SwitchMap$com$facebook$common$util$TriState = null;

        static {
            $SwitchMap$com$facebook$common$util$TriState = new int[TriState.values().length];
            try {
                $SwitchMap$com$facebook$common$util$TriState[TriState.YES.ordinal()] = 1;
            } catch (NoSuchFieldError e) {
            }
            try {
                $SwitchMap$com$facebook$common$util$TriState[TriState.NO.ordinal()] = 2;
            } catch (NoSuchFieldError e2) {
            }
            try {
                $SwitchMap$com$facebook$common$util$TriState[TriState.UNSET.ordinal()] = 3;
            } catch (NoSuchFieldError e3) {
            }
        }
    }

    public boolean isSet() {
        return this != UNSET;
    }

    public static TriState valueOf(boolean bool) {
        return bool ? YES : NO;
    }

    public static TriState valueOf(Boolean bool) {
        return bool != null ? valueOf(bool.booleanValue()) : UNSET;
    }

    public boolean asBoolean() {
        switch (AnonymousClass1.$SwitchMap$com$facebook$common$util$TriState[ordinal()]) {
            case R.styleable.View_android_focusable /*1*/:
                return true;
            case R.styleable.View_paddingStart /*2*/:
                return false;
            case R.styleable.View_paddingEnd /*3*/:
                throw new IllegalStateException("No boolean equivalent for UNSET");
            default:
                throw new IllegalStateException("Unrecognized TriState value: " + this);
        }
    }

    public boolean asBoolean(boolean defaultValue) {
        switch (AnonymousClass1.$SwitchMap$com$facebook$common$util$TriState[ordinal()]) {
            case R.styleable.View_android_focusable /*1*/:
                return true;
            case R.styleable.View_paddingStart /*2*/:
                return false;
            case R.styleable.View_paddingEnd /*3*/:
                return defaultValue;
            default:
                throw new IllegalStateException("Unrecognized TriState value: " + this);
        }
    }

    public Boolean asBooleanObject() {
        switch (AnonymousClass1.$SwitchMap$com$facebook$common$util$TriState[ordinal()]) {
            case R.styleable.View_android_focusable /*1*/:
                return Boolean.TRUE;
            case R.styleable.View_paddingStart /*2*/:
                return Boolean.FALSE;
            case R.styleable.View_paddingEnd /*3*/:
                return null;
            default:
                throw new IllegalStateException("Unrecognized TriState value: " + this);
        }
    }

    public int getDbValue() {
        switch (AnonymousClass1.$SwitchMap$com$facebook$common$util$TriState[ordinal()]) {
            case R.styleable.View_android_focusable /*1*/:
                return 1;
            case R.styleable.View_paddingStart /*2*/:
                return 2;
            default:
                return 3;
        }
    }

    public static TriState fromDbValue(int value) {
        switch (value) {
            case R.styleable.View_android_focusable /*1*/:
                return YES;
            case R.styleable.View_paddingStart /*2*/:
                return NO;
            default:
                return UNSET;
        }
    }
}
