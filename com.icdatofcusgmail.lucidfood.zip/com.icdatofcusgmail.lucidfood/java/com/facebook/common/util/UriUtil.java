package com.facebook.common.util;

import android.net.Uri;
import android.provider.ContactsContract;
import android.provider.MediaStore.Images.Media;
import javax.annotation.Nullable;

public class UriUtil {
    public static final String DATA_SCHEME = "data";
    public static final String HTTPS_SCHEME = "https";
    public static final String HTTP_SCHEME = "http";
    public static final String LOCAL_ASSET_SCHEME = "asset";
    private static final String LOCAL_CONTACT_IMAGE_PREFIX = Uri.withAppendedPath(ContactsContract.AUTHORITY_URI, "display_photo").getPath();
    public static final String LOCAL_CONTENT_SCHEME = "content";
    public static final String LOCAL_FILE_SCHEME = "file";
    public static final String LOCAL_RESOURCE_SCHEME = "res";

    @javax.annotation.Nullable
    public static java.lang.String getRealPathFromUri(android.content.ContentResolver r9, android.net.Uri r10) {
        /* JADX: method processing error */
/*
Error: jadx.core.utils.exceptions.JadxRuntimeException: Can't find block by offset: 0x002c in list [B:13:0x0029]
	at jadx.core.utils.BlockUtils.getBlockByOffset(BlockUtils.java:42)
	at jadx.core.dex.instructions.IfNode.initBlocks(IfNode.java:60)
	at jadx.core.dex.visitors.blocksmaker.BlockFinish.initBlocksInIfNodes(BlockFinish.java:48)
	at jadx.core.dex.visitors.blocksmaker.BlockFinish.visit(BlockFinish.java:33)
	at jadx.core.dex.visitors.DepthTraversal.visit(DepthTraversal.java:31)
	at jadx.core.dex.visitors.DepthTraversal.visit(DepthTraversal.java:17)
	at jadx.core.ProcessClass.process(ProcessClass.java:37)
	at jadx.api.JadxDecompiler.processClass(JadxDecompiler.java:286)
	at jadx.api.JavaClass.decompile(JavaClass.java:62)
	at jadx.api.JadxDecompiler$1.run(JadxDecompiler.java:173)
*/
        /*
        r8 = 0;
        r0 = isLocalContentUri(r10);
        if (r0 == 0) goto L_0x0034;
    L_0x0007:
        r6 = 0;
        r2 = 0;
        r3 = 0;
        r4 = 0;
        r5 = 0;
        r0 = r9;
        r1 = r10;
        r6 = r0.query(r1, r2, r3, r4, r5);	 Catch:{ all -> 0x002d }
        if (r6 == 0) goto L_0x0027;	 Catch:{ all -> 0x002d }
    L_0x0014:
        r0 = r6.moveToFirst();	 Catch:{ all -> 0x002d }
        if (r0 == 0) goto L_0x0027;	 Catch:{ all -> 0x002d }
    L_0x001a:
        r0 = "_data";	 Catch:{ all -> 0x002d }
        r7 = r6.getColumnIndex(r0);	 Catch:{ all -> 0x002d }
        r0 = -1;	 Catch:{ all -> 0x002d }
        if (r7 == r0) goto L_0x0027;	 Catch:{ all -> 0x002d }
    L_0x0023:
        r8 = r6.getString(r7);	 Catch:{ all -> 0x002d }
    L_0x0027:
        if (r6 == 0) goto L_0x002c;
    L_0x0029:
        r6.close();
    L_0x002c:
        return r8;
    L_0x002d:
        r0 = move-exception;
        if (r6 == 0) goto L_0x0033;
    L_0x0030:
        r6.close();
    L_0x0033:
        throw r0;
    L_0x0034:
        r0 = isLocalFileUri(r10);
        if (r0 == 0) goto L_0x002c;
    L_0x003a:
        r8 = r10.getPath();
        goto L_0x002c;
        */
        throw new UnsupportedOperationException("Method not decompiled: com.facebook.common.util.UriUtil.getRealPathFromUri(android.content.ContentResolver, android.net.Uri):java.lang.String");
    }

    public static boolean isNetworkUri(@Nullable Uri uri) {
        String scheme = getSchemeOrNull(uri);
        return HTTPS_SCHEME.equals(scheme) || HTTP_SCHEME.equals(scheme);
    }

    public static boolean isLocalFileUri(@Nullable Uri uri) {
        return LOCAL_FILE_SCHEME.equals(getSchemeOrNull(uri));
    }

    public static boolean isLocalContentUri(@Nullable Uri uri) {
        return LOCAL_CONTENT_SCHEME.equals(getSchemeOrNull(uri));
    }

    public static boolean isLocalContactUri(Uri uri) {
        return isLocalContentUri(uri) && "com.android.contacts".equals(uri.getAuthority()) && !uri.getPath().startsWith(LOCAL_CONTACT_IMAGE_PREFIX);
    }

    public static boolean isLocalCameraUri(Uri uri) {
        String uriString = uri.toString();
        return uriString.startsWith(Media.EXTERNAL_CONTENT_URI.toString()) || uriString.startsWith(Media.INTERNAL_CONTENT_URI.toString());
    }

    public static boolean isLocalAssetUri(@Nullable Uri uri) {
        return LOCAL_ASSET_SCHEME.equals(getSchemeOrNull(uri));
    }

    public static boolean isLocalResourceUri(@Nullable Uri uri) {
        return LOCAL_RESOURCE_SCHEME.equals(getSchemeOrNull(uri));
    }

    public static boolean isDataUri(@Nullable Uri uri) {
        return DATA_SCHEME.equals(getSchemeOrNull(uri));
    }

    @Nullable
    public static String getSchemeOrNull(@Nullable Uri uri) {
        return uri == null ? null : uri.getScheme();
    }

    public static Uri parseUriOrNull(@Nullable String uriAsString) {
        return uriAsString != null ? Uri.parse(uriAsString) : null;
    }
}
