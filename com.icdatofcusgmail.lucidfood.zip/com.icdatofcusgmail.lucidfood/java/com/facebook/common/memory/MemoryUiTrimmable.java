package com.facebook.common.memory;

public interface MemoryUiTrimmable {
    void trim();

    void untrim();
}
