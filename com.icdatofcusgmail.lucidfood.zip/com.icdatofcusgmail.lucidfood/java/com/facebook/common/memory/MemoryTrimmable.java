package com.facebook.common.memory;

public interface MemoryTrimmable {
    void trim(MemoryTrimType memoryTrimType);
}
