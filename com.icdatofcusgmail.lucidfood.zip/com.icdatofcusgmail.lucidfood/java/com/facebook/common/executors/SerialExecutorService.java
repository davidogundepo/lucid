package com.facebook.common.executors;

import java.util.concurrent.ExecutorService;

public interface SerialExecutorService extends ExecutorService {
}
