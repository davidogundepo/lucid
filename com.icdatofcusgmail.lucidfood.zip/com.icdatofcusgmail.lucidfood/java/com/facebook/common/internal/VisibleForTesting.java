package com.facebook.common.internal;

public @interface VisibleForTesting {
}
