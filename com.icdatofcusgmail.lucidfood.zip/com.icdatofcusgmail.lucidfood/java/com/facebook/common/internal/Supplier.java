package com.facebook.common.internal;

public interface Supplier<T> {
    T get();
}
