package com.facebook.drawable.base;

public interface DrawableWithCaches {
    void dropCaches();
}
