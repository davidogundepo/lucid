package com.facebook.imagepipeline.common;

public class TooManyBitmapsException extends RuntimeException {
}
