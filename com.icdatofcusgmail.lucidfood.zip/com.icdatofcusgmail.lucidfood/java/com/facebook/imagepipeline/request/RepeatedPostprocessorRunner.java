package com.facebook.imagepipeline.request;

public interface RepeatedPostprocessorRunner {
    void update();
}
