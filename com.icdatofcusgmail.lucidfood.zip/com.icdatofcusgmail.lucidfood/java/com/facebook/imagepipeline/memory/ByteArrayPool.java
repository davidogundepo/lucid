package com.facebook.imagepipeline.memory;

public interface ByteArrayPool extends Pool<byte[]> {
}
