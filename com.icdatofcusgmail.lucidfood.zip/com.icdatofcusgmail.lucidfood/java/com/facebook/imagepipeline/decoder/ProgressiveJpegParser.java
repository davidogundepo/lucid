package com.facebook.imagepipeline.decoder;

import com.facebook.common.internal.Closeables;
import com.facebook.common.internal.Preconditions;
import com.facebook.common.internal.Throwables;
import com.facebook.common.util.StreamUtil;
import com.facebook.imagepipeline.image.EncodedImage;
import com.facebook.imagepipeline.memory.ByteArrayPool;
import com.facebook.imagepipeline.memory.PooledByteArrayBufferedInputStream;
import com.facebook.imageutils.JfifUtil;
import java.io.IOException;
import java.io.InputStream;

public class ProgressiveJpegParser {
    private static final int BUFFER_SIZE = 16384;
    private static final int NOT_A_JPEG = 6;
    private static final int READ_FIRST_JPEG_BYTE = 0;
    private static final int READ_MARKER_FIRST_BYTE_OR_ENTROPY_DATA = 2;
    private static final int READ_MARKER_SECOND_BYTE = 3;
    private static final int READ_SECOND_JPEG_BYTE = 1;
    private static final int READ_SIZE_FIRST_BYTE = 4;
    private static final int READ_SIZE_SECOND_BYTE = 5;
    private int mBestScanEndOffset = READ_FIRST_JPEG_BYTE;
    private int mBestScanNumber = READ_FIRST_JPEG_BYTE;
    private final ByteArrayPool mByteArrayPool;
    private int mBytesParsed = READ_FIRST_JPEG_BYTE;
    private int mLastByteRead = READ_FIRST_JPEG_BYTE;
    private int mNextFullScanNumber = READ_FIRST_JPEG_BYTE;
    private int mParserState = READ_FIRST_JPEG_BYTE;

    public ProgressiveJpegParser(ByteArrayPool byteArrayPool) {
        this.mByteArrayPool = (ByteArrayPool) Preconditions.checkNotNull(byteArrayPool);
    }

    public boolean parseMoreData(EncodedImage encodedImage) {
        if (this.mParserState == NOT_A_JPEG) {
            return false;
        }
        if (encodedImage.getSize() <= this.mBytesParsed) {
            return false;
        }
        boolean z = (byte[]) this.mByteArrayPool.get(BUFFER_SIZE);
        InputStream bufferedDataStream = new PooledByteArrayBufferedInputStream(encodedImage.getInputStream(), z, this.mByteArrayPool);
        try {
            StreamUtil.skip(bufferedDataStream, (long) this.mBytesParsed);
            z = doParseMoreData(bufferedDataStream);
            return z;
        } catch (IOException ioe) {
            Throwables.propagate(ioe);
            return false;
        } finally {
            Closeables.closeQuietly(bufferedDataStream);
        }
    }

    private boolean doParseMoreData(InputStream inputStream) {
        int oldBestScanNumber = this.mBestScanNumber;
        while (this.mParserState != NOT_A_JPEG) {
            try {
                int nextByte = inputStream.read();
                if (nextByte != -1) {
                    this.mBytesParsed += READ_SECOND_JPEG_BYTE;
                    switch (this.mParserState) {
                        case READ_FIRST_JPEG_BYTE /*0*/:
                            if (nextByte != JfifUtil.MARKER_FIRST_BYTE) {
                                this.mParserState = NOT_A_JPEG;
                                break;
                            }
                            this.mParserState = READ_SECOND_JPEG_BYTE;
                            break;
                        case READ_SECOND_JPEG_BYTE /*1*/:
                            if (nextByte != JfifUtil.MARKER_SOI) {
                                this.mParserState = NOT_A_JPEG;
                                break;
                            }
                            this.mParserState = READ_MARKER_FIRST_BYTE_OR_ENTROPY_DATA;
                            break;
                        case READ_MARKER_FIRST_BYTE_OR_ENTROPY_DATA /*2*/:
                            if (nextByte == JfifUtil.MARKER_FIRST_BYTE) {
                                this.mParserState = READ_MARKER_SECOND_BYTE;
                                break;
                            }
                            break;
                        case READ_MARKER_SECOND_BYTE /*3*/:
                            if (nextByte != JfifUtil.MARKER_FIRST_BYTE) {
                                if (nextByte != 0) {
                                    if (nextByte == JfifUtil.MARKER_SOS || nextByte == JfifUtil.MARKER_EOI) {
                                        newScanOrImageEndFound(this.mBytesParsed - 2);
                                    }
                                    if (!doesMarkerStartSegment(nextByte)) {
                                        this.mParserState = READ_MARKER_FIRST_BYTE_OR_ENTROPY_DATA;
                                        break;
                                    }
                                    this.mParserState = READ_SIZE_FIRST_BYTE;
                                    break;
                                }
                                this.mParserState = READ_MARKER_FIRST_BYTE_OR_ENTROPY_DATA;
                                break;
                            }
                            this.mParserState = READ_MARKER_SECOND_BYTE;
                            break;
                        case READ_SIZE_FIRST_BYTE /*4*/:
                            this.mParserState = READ_SIZE_SECOND_BYTE;
                            break;
                        case READ_SIZE_SECOND_BYTE /*5*/:
                            int bytesToSkip = ((this.mLastByteRead << 8) + nextByte) - 2;
                            StreamUtil.skip(inputStream, (long) bytesToSkip);
                            this.mBytesParsed += bytesToSkip;
                            this.mParserState = READ_MARKER_FIRST_BYTE_OR_ENTROPY_DATA;
                            break;
                        default:
                            Preconditions.checkState(false);
                            break;
                    }
                    this.mLastByteRead = nextByte;
                } else if (this.mParserState != NOT_A_JPEG || this.mBestScanNumber == oldBestScanNumber) {
                    return false;
                } else {
                    return true;
                }
            } catch (IOException ioe) {
                Throwables.propagate(ioe);
            }
        }
        if (this.mParserState != NOT_A_JPEG) {
        }
        return false;
    }

    private static boolean doesMarkerStartSegment(int markerSecondByte) {
        boolean z = true;
        if (markerSecondByte == READ_SECOND_JPEG_BYTE) {
            return false;
        }
        if (markerSecondByte >= JfifUtil.MARKER_RST0 && markerSecondByte <= JfifUtil.MARKER_RST7) {
            return false;
        }
        if (markerSecondByte == JfifUtil.MARKER_EOI || markerSecondByte == JfifUtil.MARKER_SOI) {
            z = false;
        }
        return z;
    }

    private void newScanOrImageEndFound(int offset) {
        if (this.mNextFullScanNumber > 0) {
            this.mBestScanEndOffset = offset;
        }
        int i = this.mNextFullScanNumber;
        this.mNextFullScanNumber = i + READ_SECOND_JPEG_BYTE;
        this.mBestScanNumber = i;
    }

    public boolean isJpeg() {
        return this.mBytesParsed > READ_SECOND_JPEG_BYTE && this.mParserState != NOT_A_JPEG;
    }

    public int getBestScanEndOffset() {
        return this.mBestScanEndOffset;
    }

    public int getBestScanNumber() {
        return this.mBestScanNumber;
    }
}
