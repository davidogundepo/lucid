package com.facebook.imagepipeline.producers;

public class BaseProducerContextCallbacks implements ProducerContextCallbacks {
    public void onCancellationRequested() {
    }

    public void onIsPrefetchChanged() {
    }

    public void onIsIntermediateResultExpectedChanged() {
    }

    public void onPriorityChanged() {
    }
}
