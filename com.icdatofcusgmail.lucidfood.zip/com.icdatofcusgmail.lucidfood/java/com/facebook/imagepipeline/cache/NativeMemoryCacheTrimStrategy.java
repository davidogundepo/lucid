package com.facebook.imagepipeline.cache;

import com.facebook.common.logging.FLog;
import com.facebook.common.memory.MemoryTrimType;
import com.facebook.imagepipeline.cache.CountingMemoryCache.CacheTrimStrategy;
import droidninja.filepicker.R;

public class NativeMemoryCacheTrimStrategy implements CacheTrimStrategy {
    private static final String TAG = "NativeMemoryCacheTrimStrategy";

    static /* synthetic */ class AnonymousClass1 {
        static final /* synthetic */ int[] $SwitchMap$com$facebook$common$memory$MemoryTrimType = new int[MemoryTrimType.values().length];

        static {
            try {
                $SwitchMap$com$facebook$common$memory$MemoryTrimType[MemoryTrimType.OnCloseToDalvikHeapLimit.ordinal()] = 1;
            } catch (NoSuchFieldError e) {
            }
            try {
                $SwitchMap$com$facebook$common$memory$MemoryTrimType[MemoryTrimType.OnAppBackgrounded.ordinal()] = 2;
            } catch (NoSuchFieldError e2) {
            }
            try {
                $SwitchMap$com$facebook$common$memory$MemoryTrimType[MemoryTrimType.OnSystemLowMemoryWhileAppInForeground.ordinal()] = 3;
            } catch (NoSuchFieldError e3) {
            }
            try {
                $SwitchMap$com$facebook$common$memory$MemoryTrimType[MemoryTrimType.OnSystemLowMemoryWhileAppInBackground.ordinal()] = 4;
            } catch (NoSuchFieldError e4) {
            }
        }
    }

    public double getTrimRatio(MemoryTrimType trimType) {
        switch (AnonymousClass1.$SwitchMap$com$facebook$common$memory$MemoryTrimType[trimType.ordinal()]) {
            case R.styleable.View_android_focusable /*1*/:
                return 0.0d;
            case R.styleable.View_paddingStart /*2*/:
            case R.styleable.View_paddingEnd /*3*/:
            case R.styleable.View_theme /*4*/:
                return 1.0d;
            default:
                FLog.wtf(TAG, "unknown trim type: %s", trimType);
                return 0.0d;
        }
    }
}
