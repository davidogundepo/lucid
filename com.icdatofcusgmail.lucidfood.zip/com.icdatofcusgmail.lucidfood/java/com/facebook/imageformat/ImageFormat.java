package com.facebook.imageformat;

import droidninja.filepicker.R;

public enum ImageFormat {
    WEBP_SIMPLE,
    WEBP_LOSSLESS,
    WEBP_EXTENDED,
    WEBP_EXTENDED_WITH_ALPHA,
    WEBP_ANIMATED,
    JPEG,
    PNG,
    GIF,
    BMP,
    UNKNOWN;

    static /* synthetic */ class AnonymousClass1 {
        static final /* synthetic */ int[] $SwitchMap$com$facebook$imageformat$ImageFormat = null;

        static {
            $SwitchMap$com$facebook$imageformat$ImageFormat = new int[ImageFormat.values().length];
            try {
                $SwitchMap$com$facebook$imageformat$ImageFormat[ImageFormat.WEBP_SIMPLE.ordinal()] = 1;
            } catch (NoSuchFieldError e) {
            }
            try {
                $SwitchMap$com$facebook$imageformat$ImageFormat[ImageFormat.WEBP_LOSSLESS.ordinal()] = 2;
            } catch (NoSuchFieldError e2) {
            }
            try {
                $SwitchMap$com$facebook$imageformat$ImageFormat[ImageFormat.WEBP_EXTENDED.ordinal()] = 3;
            } catch (NoSuchFieldError e3) {
            }
            try {
                $SwitchMap$com$facebook$imageformat$ImageFormat[ImageFormat.WEBP_EXTENDED_WITH_ALPHA.ordinal()] = 4;
            } catch (NoSuchFieldError e4) {
            }
            try {
                $SwitchMap$com$facebook$imageformat$ImageFormat[ImageFormat.WEBP_ANIMATED.ordinal()] = 5;
            } catch (NoSuchFieldError e5) {
            }
            try {
                $SwitchMap$com$facebook$imageformat$ImageFormat[ImageFormat.JPEG.ordinal()] = 6;
            } catch (NoSuchFieldError e6) {
            }
            try {
                $SwitchMap$com$facebook$imageformat$ImageFormat[ImageFormat.PNG.ordinal()] = 7;
            } catch (NoSuchFieldError e7) {
            }
            try {
                $SwitchMap$com$facebook$imageformat$ImageFormat[ImageFormat.GIF.ordinal()] = 8;
            } catch (NoSuchFieldError e8) {
            }
            try {
                $SwitchMap$com$facebook$imageformat$ImageFormat[ImageFormat.BMP.ordinal()] = 9;
            } catch (NoSuchFieldError e9) {
            }
        }
    }

    public static boolean isWebpFormat(ImageFormat imageFormat) {
        return imageFormat == WEBP_SIMPLE || imageFormat == WEBP_LOSSLESS || imageFormat == WEBP_EXTENDED || imageFormat == WEBP_EXTENDED_WITH_ALPHA || imageFormat == WEBP_ANIMATED;
    }

    public static String getFileExtension(ImageFormat imageFormat) throws UnsupportedOperationException {
        switch (AnonymousClass1.$SwitchMap$com$facebook$imageformat$ImageFormat[imageFormat.ordinal()]) {
            case R.styleable.View_android_focusable /*1*/:
            case R.styleable.View_paddingStart /*2*/:
            case R.styleable.View_paddingEnd /*3*/:
            case R.styleable.View_theme /*4*/:
            case R.styleable.Toolbar_contentInsetStart /*5*/:
                return "webp";
            case R.styleable.Toolbar_contentInsetEnd /*6*/:
                return "jpeg";
            case R.styleable.Toolbar_contentInsetLeft /*7*/:
                return "png";
            case R.styleable.Toolbar_contentInsetRight /*8*/:
                return "gif";
            case R.styleable.Toolbar_contentInsetStartWithNavigation /*9*/:
                return "bmp";
            default:
                throw new UnsupportedOperationException("Unknown image format " + imageFormat.name());
        }
    }
}
